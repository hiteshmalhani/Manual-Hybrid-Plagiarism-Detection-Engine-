import requests
import time

print("=" * 60)
print("Testing Plagiarism Detection Backend")
print("=" * 60)

# Test queries
test_queries = [
    "Artificial intelligence and machine learning are transforming technology",
    "The team won the championship game with a last-minute goal",
    "Climate change is affecting weather patterns globally",
    "A completely original sentence that probably doesn't exist in the dataset"
]

for i, query in enumerate(test_queries, 1):
    print(f"\n📝 Test {i}: {query[:50]}...")
    
    try:
        start = time.time()
        response = requests.post(
            "http://localhost:8000/api/check-plagiarism",
            json={"text": query, "top_k": 2},
            timeout=30
        )
        elapsed = time.time() - start
        
        if response.status_code == 200:
            result = response.json()
            score = result.get("overall_score", 0)
            matches = len(result.get("matches", []))
            print(f"   ✅ Status: OK ({elapsed:.2f}s)")
            print(f"   📊 Overall Score: {score:.3f}")
            print(f"   📚 Matches found: {matches}")
            
            if matches > 0 and result.get("matches"):
                top = result["matches"][0]
                print(f"   🏆 Top match: {top.get('category', 'Unknown')} - Score: {top.get('similarity', 0):.3f}")
        else:
            print(f"   ❌ Error: HTTP {response.status_code}")
            
    except requests.exceptions.ConnectionError:
        print("   ❌ Backend not running! Start with: cd backend; uvicorn app.main:app --reload")
        break
    except Exception as e:
        print(f"   ❌ Error: {str(e)}")

print("\n" + "=" * 60)