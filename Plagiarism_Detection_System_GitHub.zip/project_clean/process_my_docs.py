"""
Process all your document files and prepare for Phase 2
"""

import sys
import json
from pathlib import Path
from datetime import datetime

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent / "backend"))

from core.cleaning import get_cleaner
from core.config import RAW_DATA_DIR, PROCESSED_DATA_DIR

def process_all_documents():
    """Process all .txt files in the data folder"""
    
    print("🚀 Starting Phase 1: Document Processing")
    print("=" * 70)
    
    # Check if data folder exists
    if not RAW_DATA_DIR.exists():
        print(f"❌ Data folder not found: {RAW_DATA_DIR}")
        print(f"Creating folder... Please add your .txt files to: {RAW_DATA_DIR}")
        RAW_DATA_DIR.mkdir(parents=True, exist_ok=True)
        return
    
    # Find all text files
    txt_files = list(RAW_DATA_DIR.rglob("*.txt"))
    
    if not txt_files:
        print(f"❌ No .txt files found in {RAW_DATA_DIR}")
        print("\nPlease move your document files (like doc_102.txt) to:")
        print(f"  {RAW_DATA_DIR}")
        return
    
    print(f"📂 Found {len(txt_files)} document(s) to process\n")
    
    cleaner = get_cleaner()
    results = []
    
    for i, file_path in enumerate(txt_files, 1):
        print(f"[{i}/{len(txt_files)}] Processing: {file_path.name}")
        
        try:
            # Read document
            with open(file_path, 'r', encoding='utf-8') as f:
                raw_text = f.read()
            
            # Clean document
            cleaned_tokens = cleaner.clean_document(raw_text)
            
            # Store metadata
            result = {
                "id": i - 1,  # 0-based index
                "file_name": file_path.name,
                "file_path": str(file_path),
                "category": file_path.parent.name if file_path.parent != RAW_DATA_DIR else "uncategorized",
                "original_length": len(raw_text),
                "original_word_count": len(raw_text.split()),
                "cleaned_tokens": cleaned_tokens,
                "cleaned_word_count": len(cleaned_tokens),
                "cleaned_text": " ".join(cleaned_tokens)
            }
            results.append(result)
            
            print(f"   ✅ {result['original_word_count']} → {result['cleaned_word_count']} tokens")
            
        except Exception as e:
            print(f"   ❌ Error: {e}")
    
    # Save results
    metadata_file = PROCESSED_DATA_DIR / "lookup_metadata.json"
    with open(metadata_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    # Save cleaned texts for Phase 2
    cleaned_texts_file = PROCESSED_DATA_DIR / "cleaned_texts.json"
    with open(cleaned_texts_file, 'w', encoding='utf-8') as f:
        json.dump([r["cleaned_text"] for r in results], f, indent=2, ensure_ascii=False)
    
    print("\n" + "=" * 70)
    print("✅ PHASE 1 COMPLETE!")
    print("=" * 70)
    print(f"📊 Processed: {len(results)} documents")
    print(f"💾 Metadata saved: {metadata_file}")
    print(f"💾 Cleaned texts saved: {cleaned_texts_file}")
    
    # Statistics
    total_original = sum(r["original_word_count"] for r in results)
    total_cleaned = sum(r["cleaned_word_count"] for r in results)
    reduction = (1 - total_cleaned/total_original) * 100 if total_original > 0 else 0
    
    print(f"\n📈 Overall Statistics:")
    print(f"   Total original words: {total_original}")
    print(f"   Total cleaned tokens: {total_cleaned}")
    print(f"   Reduction: {reduction:.1f}%")
    
    return results

if __name__ == "__main__":
    process_all_documents()