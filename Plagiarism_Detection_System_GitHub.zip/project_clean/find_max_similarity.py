"""
Find the highest similarity pair in the corpus
"""

import sys
import numpy as np
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "backend"))

from core.semantic_engine import SemanticEngine

def find_max_similarity():
    print("=" * 70)
    print("FINDING MAXIMUM SIMILARITY IN CORPUS")
    print("=" * 70)
    
    engine = SemanticEngine()
    
    # Sample a subset (checking all 20k² pairs would take too long)
    sample_size = min(1000, engine.corpus_matrix.shape[0])
    print(f"\nSampling {sample_size} documents...")
    
    # Take first N documents
    sample_matrix = engine.corpus_matrix[:sample_size]
    
    # Compute similarity matrix (all pairs)
    similarities = np.dot(sample_matrix, sample_matrix.T)
    
    # Find maximum similarity (excluding self-similarity = 1.0)
    np.fill_diagonal(similarities, 0)  # Remove self-similarity
    max_idx = np.unravel_index(np.argmax(similarities), similarities.shape)
    max_score = similarities[max_idx]
    
    print(f"\n🏆 HIGHEST SIMILARITY FOUND: {max_score:.6f}")
    print(f"   Document 1: {engine.metadata[max_idx[0]]['file_name']}")
    print(f"   Document 2: {engine.metadata[max_idx[1]]['file_name']}")
    
    # Check if they're actually duplicates
    doc1_text = engine.metadata[max_idx[0]]['cleaned_text'][:200]
    doc2_text = engine.metadata[max_idx[1]]['cleaned_text'][:200]
    
    print(f"\n📄 Document 1 preview: {doc1_text}...")
    print(f"\n📄 Document 2 preview: {doc2_text}...")
    
    # Explanation
    print("\n" + "=" * 70)
    print("💡 INSIGHT:")
    if max_score > 0.85:
        print("   These documents are VERY similar - possible duplicates!")
    elif max_score > 0.70:
        print("   These documents are highly related - same topic with variations")
    else:
        print("   No exact duplicates found - corpus has diverse content")
        print(f"   Your scores of 0.56-0.65 are NORMAL for this corpus!")

if __name__ == "__main__":
    find_max_similarity()