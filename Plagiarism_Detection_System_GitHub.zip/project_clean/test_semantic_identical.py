"""
Test semantic engine with identical text to see scores near 1.0
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "backend"))

from core.semantic_engine import SemanticEngine
from core.cleaning import get_cleaner

def test_identical_matching():
    print("=" * 70)
    print("TESTING SEMANTIC SIMILARITY WITH IDENTICAL TEXT")
    print("=" * 70)
    
    engine = SemanticEngine()
    cleaner = get_cleaner()
    
    # Test 1: Query with text that exactly matches a document
    print("\n📝 TEST 1: Query exactly matching a document in corpus")
    print("-" * 70)
    
    # Get the first document's cleaned text
    first_doc = engine.metadata[0]
    query_text = first_doc['cleaned_text']
    
    print(f"Document: {first_doc['file_name']}")
    print(f"Query (first 100 chars): {query_text[:100]}...")
    
    results = engine.get_top_k(query_text, k=3)
    
    print("\n🔍 Results:")
    for i, result in enumerate(results, 1):
        print(f"\n{i}. Score: {result['similarity_score']:.6f}")
        print(f"   File: {result['file_name']}")
        print(f"   Category: {result['category']}")
        
        # Check if this is the same document
        if result['index'] == 0:
            print("   ✓ THIS IS THE EXACT SAME DOCUMENT!")
    
    # Test 2: Query with slight variations
    print("\n\n📝 TEST 2: Query with minor variations")
    print("-" * 70)
    
    original_text = "stock market trends attracted major public attention"
    variations = [
        "stock market trends attracted major public attention",  # Exact
        "stock market trends attracted public attention",        # Missing "major"
        "stock market trends",                                   # Shorter
        "completely different topic about space exploration",    # Different
    ]
    
    for var in variations:
        results = engine.get_top_k(var, k=1)
        score = results[0]['similarity_score']
        print(f"\nQuery: '{var[:50]}...'")
        print(f"Top match score: {score:.6f}")
        print(f"Match file: {results[0]['file_name']}")
    
    # Test 3: Cosine similarity explanation
    print("\n\n📚 UNDERSTANDING COSINE SIMILARITY SCORES")
    print("-" * 70)
    print("""
    Cosine similarity ranges from -1 to 1:
    - 1.0000 = Identical vectors (same document)
    - 0.7000-0.9999 = Very similar (same topic, different wording)
    - 0.5000-0.6999 = Related (different but relevant)
    - 0.3000-0.4999 = Weakly related
    - 0.0000-0.2999 = Unrelated
    - Negative = Opposite meanings (rare)
    
    Your scores of 0.56-0.65 indicate RELATED documents,
    not exact matches. This is GOOD for plagiarism detection!
    """)

if __name__ == "__main__":
    test_identical_matching()