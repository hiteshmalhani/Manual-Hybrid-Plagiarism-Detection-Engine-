"""
Check what files you already have
"""

from pathlib import Path

print("🔍 Checking your project status...")
print("=" * 70)

# Check for files
files_to_check = [
    ("backend/data/processed/lookup_metadata.json", "Phase 2 Metadata"),
    ("backend/data/processed/corpus_matrix.npy", "Phase 2 Embeddings"),
    ("backend/data/20newsgroups/", "Source Documents"),
    ("backend/core/cleaning.py", "Phase 1 Cleaner"),
]

for file_path, description in files_to_check:
    if Path(file_path).exists():
        size = Path(file_path).stat().st_size if Path(file_path).is_file() else "N/A"
        print(f"✅ {description}: EXISTS")
        if size != "N/A":
            print(f"   Size: {size:,} bytes")
    else:
        print(f"❌ {description}: MISSING")

print("\n" + "=" * 70)

# If you have lookup_metadata.json, show its structure
metadata_file = Path("backend/data/processed/lookup_metadata.json")
if metadata_file.exists():
    import json
    with open(metadata_file, 'r') as f:
        data = json.load(f)
    
    print("\n📄 Your lookup_metadata.json contains:")
    print(f"   Type: {type(data)}")
    if isinstance(data, list) and len(data) > 0:
        print(f"   Number of entries: {len(data)}")
        print(f"   First entry keys: {list(data[0].keys()) if isinstance(data[0], dict) else 'List of values'}")
    elif isinstance(data, dict):
        print(f"   Keys: {list(data.keys())[:5]}")