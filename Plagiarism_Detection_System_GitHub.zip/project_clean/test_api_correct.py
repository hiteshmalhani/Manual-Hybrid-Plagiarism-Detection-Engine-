import requests
import json

print("=" * 60)
print("Testing Plagiarism Detection API")
print("=" * 60)

# Test queries
test_queries = [
    {
        "name": "Technology/AI",
        "text": "Artificial intelligence and machine learning are transforming how computers understand and process information. Deep learning algorithms can recognize patterns in large datasets."
    },
    {
        "name": "Sports",
        "text": "The team won the championship after an exciting game. The fans celebrated late into the night."
    },
    {
        "name": "Science/Environment",
        "text": "Climate change is causing global temperatures to rise and weather patterns to become more extreme."
    },
    {
        "name": "Business",
        "text": "Stock market investments require careful analysis of market trends and economic indicators."
    }
]

for test in test_queries:
    print(f"\n📝 Testing: {test['name']}")
    print("-" * 40)
    
    try:
        response = requests.post(
            "http://localhost:8000/api/analyze",  # Correct endpoint!
            json={"text": test["text"]},
            timeout=30
        )
        
        if response.status_code == 200:
            results = response.json()
            print(f"✅ Status: OK")
            print(f"📊 Found {len(results)} matches")
            
            # Show top 3 matches
            for i, match in enumerate(results[:3], 1):
                print(f"\n   🏆 Match {i}:")
                print(f"      File: {match.get('filename', 'Unknown')}")
                print(f"      Category: {match.get('category', 'Unknown')}")
                print(f"      Combined Score: {match.get('combined_score', 0):.4f}")
                print(f"      Lexical Score: {match.get('lexical_score', 0):.4f}")
                print(f"      Semantic Score: {match.get('semantic_score', 0):.4f}")
        else:
            print(f"❌ Error: HTTP {response.status_code}")
            print(f"   Response: {response.text}")
            
    except Exception as e:
        print(f"❌ Error: {str(e)}")

print("\n" + "=" * 60)
print("✅ Testing complete!")