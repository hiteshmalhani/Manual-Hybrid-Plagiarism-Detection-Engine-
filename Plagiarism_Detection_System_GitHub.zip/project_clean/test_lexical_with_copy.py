"""
Test lexical similarity with actual copied text
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "backend"))

from core.lexical_engine import LexicalEngine

def test_with_copy():
    print("\n" + "=" * 70)
    print("TESTING LEXICAL SIMILARITY WITH COPYING")
    print("=" * 70)
    
    engine = LexicalEngine()
    
    # Original text
    original = "Officials confirmed that recent stock market trends have attracted major public attention in Paris"
    
    # Different levels of copying
    tests = [
        ("No copy", "Space exploration reaches new milestones"),
        ("Paraphrase", "Government officials announced that stock market movements have gained significant public focus"),
        ("Some copy", "Officials confirmed that stock market trends have attracted attention"),
        ("Heavy copy", "Officials confirmed that recent stock market trends have attracted major public attention"),
        ("Exact copy", original)
    ]
    
    print("\n📊 Lexical Similarity Scores:")
    print("-" * 70)
    
    for label, text in tests:
        result = engine.analyze_text_pair(original, text)
        print(f"\n{label}:")
        print(f"  Text: {text[:60]}...")
        print(f"  Score: {result['jaccard_similarity']:.4f}")
        print(f"  Matching shingles: {result['num_matches']}")
        
        if result['matching_shingles']:
            print(f"  Example: '{result['matching_shingles'][0]}'")

if __name__ == "__main__":
    test_with_copy()