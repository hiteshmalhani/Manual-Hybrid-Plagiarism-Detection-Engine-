"""
Diagnose why parallel worker is slow
"""

import time
import sys
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "backend"))

from core.cleaning import get_cleaner
from core.lexical_engine import LexicalEngine

def test_sequential_speed():
    """Test sequential processing speed"""
    print("\n" + "=" * 70)
    print("SPEED DIAGNOSTIC TEST")
    print("=" * 70)
    
    # Load documents
    metadata_path = Path("backend/data/processed/lookup_metadata.json")
    with open(metadata_path, 'r') as f:
        all_docs = json.load(f)
    
    test_docs = all_docs[:10]
    query = "stock market trends and financial investments"
    
    cleaner = get_cleaner()
    query_tokens = cleaner.clean_query(query)
    
    engine = LexicalEngine()
    
    # Test single document processing time
    print("\n📊 Testing single document processing time...")
    
    times = []
    for i, doc in enumerate(test_docs[:5]):
        doc_tokens = doc.get('cleaned_tokens', [])
        
        start = time.time()
        result = engine.analyze_cleaned_tokens(query_tokens, doc_tokens)
        elapsed = time.time() - start
        
        times.append(elapsed)
        print(f"   Doc {i+1}: {elapsed:.4f}s - {doc['file_name']}")
    
    avg_time = sum(times) / len(times)
    print(f"\n📈 Average per document: {avg_time:.4f}s")
    print(f"📈 5 documents sequential: {avg_time * 5:.2f}s")
    print(f"📈 5 documents parallel overhead: {avg_time * 5 * 1.5:.2f}s (with overhead)")
    
    print("\n" + "=" * 70)
    print("DIAGNOSIS:")
    print("=" * 70)
    
    if avg_time > 5:
        print("❌ EACH DOCUMENT TAKES >5 SECONDS - MAJOR ISSUE!")
        print("   Possible causes:")
        print("   1. Model reloading for each document")
        print("   2. Tokenization overhead")
        print("   3. Large document sizes")
    elif avg_time > 1:
        print("⚠️ Each document takes 1-5 seconds - MODERATE ISSUE")
        print("   Consider caching or optimization")
    else:
        print(f"✅ Each document takes {avg_time:.3f}s - GOOD!")
        print(f"   The 40s delay is from multiprocessing OVERHEAD, not the algorithm")
    
    return avg_time

def test_model_reload_issue():
    """Check if model is being reloaded"""
    print("\n" + "=" * 70)
    print("CHECKING FOR MODEL RELOADS")
    print("=" * 70)
    
    from core.lexical_engine import LexicalEngine
    import gc
    
    # First call - should load everything
    start = time.time()
    engine1 = LexicalEngine()
    time1 = time.time() - start
    
    # Second call - should be faster (cache?)
    start = time.time()
    engine2 = LexicalEngine()
    time2 = time.time() - start
    
    print(f"\nFirst engine init: {time1:.4f}s")
    print(f"Second engine init: {time2:.4f}s")
    
    if time2 < time1 * 0.5:
        print("✅ Models are cached - good!")
    else:
        print("⚠️ Models are being reloaded each time - this is the problem!")
        print("   Each parallel worker reloads the model = SLOW")

if __name__ == "__main__":
    test_sequential_speed()
    test_model_reload_issue()