"""
Phase 4: Lexical Engine - Manual 3-word Shingling & Jaccard Similarity
No external similarity libraries - pure set operations!
"""

from typing import List, Set, Dict
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from core.cleaning import get_cleaner
from core.config import SHINGLE_SIZE

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class LexicalEngine:
    """
    Lexical similarity analyzer using word-level shingling.
    """
    
    def __init__(self, shingle_size: int = SHINGLE_SIZE):
        self.shingle_size = shingle_size
        self.cleaner = get_cleaner()
        logger.info(f"Lexical Engine initialized with shingle_size={shingle_size}")
    
    def generate_word_shingles(self, tokens: List[str]) -> Set[str]:
        """
        Generate overlapping word shingles from token list.
        """
        if not tokens or len(tokens) < self.shingle_size:
            return set()
        
        shingles = set()
        for i in range(len(tokens) - self.shingle_size + 1):
            shingle = ' '.join(tokens[i:i + self.shingle_size])
            shingles.add(shingle)
        
        return shingles
    
    def compute_jaccard_similarity(self, set_a: Set[str], set_b: Set[str]) -> float:
        """
        Compute Jaccard similarity coefficient manually.
        """
        if not set_a or not set_b:
            return 0.0
        
        intersection_size = len(set_a.intersection(set_b))
        union_size = len(set_a) + len(set_b) - intersection_size
        
        if union_size == 0:
            return 0.0
        
        return round(intersection_size / union_size, 6)
    
    def find_matching_shingles(self, query_shingles: Set[str], doc_shingles: Set[str]) -> List[str]:
        """
        Find shingles that appear in both query and document.
        """
        matches = query_shingles.intersection(doc_shingles)
        return sorted(list(matches))
    
    def analyze_text_pair(self, query_text: str, document_text: str) -> Dict:
        """
        Analyze two text strings for lexical similarity.
        """
        query_tokens = self.cleaner.clean_query(query_text)
        doc_tokens = self.cleaner.clean_document(document_text)
        
        if not query_tokens or not doc_tokens:
            return {
                'jaccard_similarity': 0.0,
                'matching_shingles': [],
                'num_matches': 0,
                'query_shingle_count': 0,
                'doc_shingle_count': 0
            }
        
        query_shingles = self.generate_word_shingles(query_tokens)
        doc_shingles = self.generate_word_shingles(doc_tokens)
        
        jaccard_score = self.compute_jaccard_similarity(query_shingles, doc_shingles)
        matching = self.find_matching_shingles(query_shingles, doc_shingles)
        
        return {
            'jaccard_similarity': jaccard_score,
            'matching_shingles': matching,
            'num_matches': len(matching),
            'query_shingle_count': len(query_shingles),
            'doc_shingle_count': len(doc_shingles)
        }
    
    def analyze_cleaned_tokens(self, query_tokens: List[str], doc_tokens: List[str]) -> Dict:
        """
        Analyze two token lists directly (avoids re-cleaning).
        """
        if not query_tokens or not doc_tokens:
            return {
                'jaccard_similarity': 0.0,
                'matching_shingles': [],
                'num_matches': 0,
                'query_shingle_count': 0,
                'doc_shingle_count': 0
            }
        
        query_shingles = self.generate_word_shingles(query_tokens)
        doc_shingles = self.generate_word_shingles(doc_tokens)
        
        jaccard_score = self.compute_jaccard_similarity(query_shingles, doc_shingles)
        matching = self.find_matching_shingles(query_shingles, doc_shingles)
        
        return {
            'jaccard_similarity': jaccard_score,
            'matching_shingles': matching,
            'num_matches': len(matching),
            'query_shingle_count': len(query_shingles),
            'doc_shingle_count': len(doc_shingles)
        }


# ============= TESTING =============

if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("PHASE 4: LEXICAL ENGINE TEST")
    print("=" * 70)
    
    engine = LexicalEngine()
    cleaner = get_cleaner()
    
    # Test 1: Shingle generation
    print("\n✅ TEST 1: Shingle Generation")
    text = "the quick brown fox jumps over the lazy dog"
    tokens = cleaner.clean_query(text)
    shingles = engine.generate_word_shingles(tokens)
    print(f"   Text: {text}")
    print(f"   Shingles ({len(shingles)}): {list(shingles)[:4]}...")
    
    # Test 2: Jaccard similarity
    print("\n✅ TEST 2: Jaccard Similarity")
    text_a = "stock market trends and investments"
    text_b = "stock market trends and analysis"
    text_c = "completely different topic"
    
    result_ab = engine.analyze_text_pair(text_a, text_b)
    result_ac = engine.analyze_text_pair(text_a, text_c)
    
    print(f"   Similar texts Jaccard: {result_ab['jaccard_similarity']:.4f}")
    print(f"   Different texts Jaccard: {result_ac['jaccard_similarity']:.4f}")
    
    # Test 3: Matching shingles
    print("\n✅ TEST 3: Matching Shingles")
    text_a = "officials confirmed recent stock market trends"
    text_b = "stock market trends attracted major attention"
    result = engine.analyze_text_pair(text_a, text_b)
    print(f"   Matching shingles: {result['num_matches']}")
    if result['matching_shingles']:
        print(f"   Example: '{result['matching_shingles'][0]}'")
    
    print("\n" + "=" * 70)
    print("✅ LEXICAL ENGINE READY!")
    print("=" * 70)