"""
Configuration settings for the plagiarism detection engine.
Centralized paths and constants.
"""

import os
from pathlib import Path

# Base paths
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
RAW_DATA_DIR = DATA_DIR / "20newsgroups"
PROCESSED_DATA_DIR = DATA_DIR / "processed"

# Ensure directories exist
RAW_DATA_DIR.mkdir(parents=True, exist_ok=True)
PROCESSED_DATA_DIR.mkdir(parents=True, exist_ok=True)

# Model configuration
EMBEDDING_MODEL_NAME = "all-MiniLM-L6-v2"
EMBEDDING_DIMENSION = 384

# Model alias (for compatibility)
EMBEDDING_MODEL = EMBEDDING_MODEL_NAME
EMBEDDING_DIM = EMBEDDING_DIMENSION

# Corpus configuration
EXPECTED_NUM_DOCUMENTS = 20000

# File paths
CORPUS_MATRIX_PATH = PROCESSED_DATA_DIR / "corpus_matrix.npy"
METADATA_INDEX_PATH = PROCESSED_DATA_DIR / "lookup_metadata.json"

# For compatibility with different naming
METADATA_PATH = METADATA_INDEX_PATH

# Cleaning configuration
STOPWORDS_LANGUAGE = 'english'
MIN_TOKEN_LENGTH = 2

# Semantic search configuration
TOP_K_SEMANTIC_RESULTS = 5
TOP_K_RESULTS = TOP_K_SEMANTIC_RESULTS  # Alias for compatibility

# Lexical configuration
SHINGLE_SIZE = 3
MAX_PARALLEL_WORKERS = 4  # Number of CPU cores for parallel processing

# API Configuration
API_HOST = "127.0.0.1"
API_PORT = 8000

# Logging
LOG_LEVEL = "INFO"