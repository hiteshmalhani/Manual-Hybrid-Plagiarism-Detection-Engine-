"""
Phase 4: Parallel Processing Worker for Lexical Analysis
"""

from concurrent.futures import ThreadPoolExecutor
from typing import List, Dict, Optional
import logging
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.lexical_engine import LexicalEngine
from core.cleaning import get_cleaner

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global cache - prevents reloading
_engine_cache = None

def get_cached_engine():
    global _engine_cache
    if _engine_cache is None:
        _engine_cache = LexicalEngine()
    return _engine_cache


class ParallelLexicalWorker:
    """OPTIMIZED - Much faster!"""
    
    def __init__(self, max_workers: Optional[int] = None):
        self.max_workers = max_workers or min(os.cpu_count() or 4, 8)
        logger.info(f"Fast worker with {self.max_workers} threads")
    
    def process_candidates_parallel(self, query_text: str, candidates: List[Dict]) -> List[Dict]:
        if not candidates:
            return []
        
        cleaner = get_cleaner()
        query_tokens = cleaner.clean_query(query_text)
        
        if not query_tokens:
            return candidates
        
        engine = get_cached_engine()
        query_shingles = engine.generate_word_shingles(query_tokens)
        
        def process_one(candidate):
            doc_tokens = candidate.get('cleaned_tokens', [])
            doc_shingles = engine.generate_word_shingles(doc_tokens)
            
            if not query_shingles or not doc_shingles:
                candidate['lexical_score'] = 0.0
                candidate['matching_shingles'] = []
                candidate['num_matches'] = 0
                return candidate
            
            intersection = len(query_shingles & doc_shingles)
            union = len(query_shingles) + len(doc_shingles) - intersection
            jaccard = intersection / union if union > 0 else 0.0
            
            candidate['lexical_score'] = round(jaccard, 6)
            candidate['matching_shingles'] = list(query_shingles & doc_shingles)[:10]
            candidate['num_matches'] = intersection
            return candidate
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            results = list(executor.map(process_one, candidates))
        
        results.sort(key=lambda x: x.get('lexical_score', 0), reverse=True)
        return results