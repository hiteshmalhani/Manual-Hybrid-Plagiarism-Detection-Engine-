"""
Phase 1: Data Cleaning Module for Plagiarism Detection
Handles text normalization, tokenization, and stopword removal
"""

import re
import nltk
from nltk.corpus import stopwords
from typing import List, Set, Dict, Any
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Ensure NLTK data is available
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords', quiet=True)
    nltk.download('punkt', quiet=True)


class TextCleaner:
    """
    Text cleaning pipeline for plagiarism detection.
    Handles both newsgroup documents and user queries.
    """
    
    def __init__(self, language: str = 'english', min_token_length: int = 2):
        """
        Initialize the text cleaner.
        
        Args:
            language: Language for stopwords
            min_token_length: Minimum token length to keep
        """
        self.stopwords_set: Set[str] = set(stopwords.words(language))
        self.min_token_length = min_token_length
        
        # Compile regex patterns for performance
        self.non_alphanumeric = re.compile(r'[^\w\s]', re.UNICODE)
        self.whitespace = re.compile(r'\s+')
        
        logger.info(f"TextCleaner ready with {len(self.stopwords_set)} stopwords")
    
    def normalize_text(self, text: str) -> str:
        """Convert to lowercase and remove punctuation."""
        if not text:
            return ""
        
        # Lowercase
        text = text.lower()
        
        # Remove punctuation and special characters
        text = self.non_alphanumeric.sub(' ', text)
        
        # Collapse multiple spaces
        text = self.whitespace.sub(' ', text)
        
        return text.strip()
    
    def tokenize(self, text: str) -> List[str]:
        """Split text into word tokens."""
        if not text:
            return []
        
        # Split on whitespace
        tokens = text.split()
        
        # Remove pure numbers
        tokens = [t for t in tokens if not t.isdigit()]
        
        return tokens
    
    def remove_stopwords(self, tokens: List[str]) -> List[str]:
        """Filter out stopwords and short tokens."""
        if not tokens:
            return []
        
        filtered = [
            token for token in tokens 
            if token not in self.stopwords_set 
            and len(token) >= self.min_token_length
        ]
        
        return filtered
    
    def clean_document(self, raw_text: str) -> List[str]:
        """
        Complete cleaning pipeline for documents.
        
        Args:
            raw_text: Raw document text
            
        Returns:
            List of cleaned tokens
        """
        if not raw_text:
            return []
        
        # Normalize (lowercase + remove punctuation)
        normalized = self.normalize_text(raw_text)
        
        # Tokenize
        tokens = self.tokenize(normalized)
        
        # Remove stopwords
        cleaned = self.remove_stopwords(tokens)
        
        return cleaned
    
    def clean_query(self, raw_text: str) -> List[str]:
        """Clean user query (same as document but without header stripping)."""
        return self.clean_document(raw_text)
    
    def reconstruct_text(self, tokens: List[str]) -> str:
        """Reconstruct text from tokens for display."""
        return ' '.join(tokens)


# Singleton instance
_cleaner = None

def get_cleaner() -> TextCleaner:
    global _cleaner
    if _cleaner is None:
        _cleaner = TextCleaner()
    return _cleaner


# Test with your document
if __name__ == "__main__":
    # Your actual document content
    test_doc = """Officials confirmed that recent developments regarding stock market trends have attracted major public attention in Paris. Authorities emphasized that training programs and infrastructure upgrades will continue over the coming months. Authorities emphasized that training programs and infrastructure upgrades will continue over the coming months. Observers believe the initiative could influence future policy discussions and strengthen international cooperation."""
    
    cleaner = get_cleaner()
    
    print("=" * 70)
    print("TESTING ON YOUR DOCUMENT: doc_102.txt")
    print("=" * 70)
    
    print("\n📄 ORIGINAL TEXT:")
    print("-" * 70)
    print(test_doc)
    
    cleaned = cleaner.clean_document(test_doc)
    
    print("\n🧹 CLEANED TOKENS:")
    print("-" * 70)
    print(cleaned)
    
    print("\n📊 STATISTICS:")
    print("-" * 70)
    print(f"Original words: {len(test_doc.split())}")
    print(f"Cleaned tokens: {len(cleaned)}")
    print(f"Removed: {len(test_doc.split()) - len(cleaned)} stopwords/punctuation")
    
    print("\n✅ Phase 1 cleaning module is ready!")