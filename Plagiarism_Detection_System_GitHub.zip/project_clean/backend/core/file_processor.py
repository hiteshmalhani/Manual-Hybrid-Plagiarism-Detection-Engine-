"""
File Processing Module - Extract text from various file types
Supports: .txt, .pdf, .docx, .md, .rtf, .html
"""

import os
from pathlib import Path
import logging
from typing import Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FileProcessor:
    """Extract text from various file formats"""
    
    SUPPORTED_EXTENSIONS = {
        '.txt': 'text/plain',
        '.md': 'text/markdown',
        '.pdf': 'application/pdf',
        '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        '.rtf': 'application/rtf',
        '.html': 'text/html',
        '.htm': 'text/html'
    }
    
    @staticmethod
    def extract_text_from_file(file_path: str) -> Optional[str]:
        """Extract text from uploaded file"""
        file_ext = Path(file_path).suffix.lower()
        
        logger.info(f"Processing file: {file_path}, extension: {file_ext}")
        
        if file_ext == '.txt':
            return FileProcessor._read_text_file(file_path)
        elif file_ext == '.pdf':
            return FileProcessor._read_pdf_file(file_path)
        elif file_ext == '.docx':
            return FileProcessor._read_docx_file(file_path)
        elif file_ext == '.md':
            return FileProcessor._read_text_file(file_path)
        elif file_ext in ['.html', '.htm']:
            return FileProcessor._read_html_file(file_path)
        elif file_ext == '.rtf':
            return FileProcessor._read_text_file(file_path)
        else:
            # Try to read as text
            return FileProcessor._read_text_file(file_path)
    
    @staticmethod
    def _read_text_file(file_path: str) -> Optional[str]:
        """Read plain text files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                logger.info(f"Successfully read text file: {len(content)} characters")
                return content
        except UnicodeDecodeError:
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    content = f.read()
                    logger.info(f"Successfully read text file (latin-1): {len(content)} characters")
                    return content
            except Exception as e:
                logger.error(f"Error reading text file: {e}")
                return None
        except Exception as e:
            logger.error(f"Error reading text file: {e}")
            return None
    
    @staticmethod
    def _read_pdf_file(file_path: str) -> Optional[str]:
        """Extract text from PDF files"""
        try:
            from PyPDF2 import PdfReader
            text = ""
            with open(file_path, 'rb') as f:
                reader = PdfReader(f)
                for page in reader.pages:
                    text += page.extract_text()
            logger.info(f"Successfully read PDF file: {len(text)} characters")
            return text if text else None
        except ImportError:
            logger.error("PyPDF2 not installed. Run: pip install PyPDF2")
            return None
        except Exception as e:
            logger.error(f"Error reading PDF: {e}")
            return None
    
    @staticmethod
    def _read_docx_file(file_path: str) -> Optional[str]:
        """Extract text from DOCX files"""
        try:
            import docx
            doc = docx.Document(file_path)
            text = '\n'.join([paragraph.text for paragraph in doc.paragraphs])
            logger.info(f"Successfully read DOCX file: {len(text)} characters")
            return text if text else None
        except ImportError:
            logger.error("python-docx not installed. Run: pip install python-docx")
            return None
        except Exception as e:
            logger.error(f"Error reading DOCX: {e}")
            return None
    
    @staticmethod
    def _read_html_file(file_path: str) -> Optional[str]:
        """Extract text from HTML files"""
        try:
            from bs4 import BeautifulSoup
            with open(file_path, 'r', encoding='utf-8') as f:
                soup = BeautifulSoup(f.read(), 'html.parser')
                text = soup.get_text()
                logger.info(f"Successfully read HTML file: {len(text)} characters")
                return text
        except ImportError:
            logger.error("BeautifulSoup not installed. Run: pip install beautifulsoup4")
            return FileProcessor._read_text_file(file_path)
        except Exception as e:
            logger.error(f"Error reading HTML: {e}")
            return None