"""
Phase 2: Memory-Mapped Embedding Index Module
Creates dense vector embeddings for all documents and saves as memory-mapped array
"""

import json
import numpy as np
from pathlib import Path
from sentence_transformers import SentenceTransformer
from tqdm import tqdm
import logging
import sys
from typing import List, Dict, Any

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.config import (
    PROCESSED_DATA_DIR,
    EMBEDDING_MODEL,
    EMBEDDING_DIM,
    CORPUS_MATRIX_PATH,
    METADATA_PATH
)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class EmbeddingIndexer:
    """
    Creates and manages memory-mapped embedding index for all documents.
    """
    
    def __init__(self, model_name: str = EMBEDDING_MODEL):
        """
        Initialize the embedding model.
        
        Args:
            model_name: SentenceTransformer model to use
        """
        logger.info(f"Loading embedding model: {model_name}")
        self.model = SentenceTransformer(model_name)
        self.model_name = model_name
        self.embedding_dim = self.model.get_sentence_embedding_dimension()
        logger.info(f"Model loaded. Embedding dimension: {self.embedding_dim}")
    
    def load_cleaned_documents(self, metadata_file: Path) -> List[str]:
        """
        Load cleaned document texts from metadata JSON.
        
        Args:
            metadata_file: Path to lookup_metadata.json
            
        Returns:
            List of cleaned text strings
        """
        logger.info(f"Loading cleaned documents from: {metadata_file}")
        
        with open(metadata_file, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
        
        # Extract cleaned_text from each document
        cleaned_texts = [doc['cleaned_text'] for doc in metadata]
        
        logger.info(f"Loaded {len(cleaned_texts)} documents")
        
        # Show sample
        if cleaned_texts:
            logger.info(f"Sample document (first 100 chars): {cleaned_texts[0][:100]}...")
        
        return cleaned_texts
    
    def create_memory_mapped_matrix(self, num_documents: int) -> np.memmap:
        """
        Create a memory-mapped numpy array on disk.
        
        Args:
            num_documents: Number of documents to index
            
        Returns:
            Memory-mapped numpy array
        """
        logger.info(f"Creating memory-mapped matrix of shape: ({num_documents}, {self.embedding_dim})")
        
        # Ensure directory exists
        CORPUS_MATRIX_PATH.parent.mkdir(parents=True, exist_ok=True)
        
        # Create memory-mapped array
        matrix = np.memmap(
            str(CORPUS_MATRIX_PATH),
            dtype='float32',
            mode='w+',
            shape=(num_documents, self.embedding_dim)
        )
        
        # Initialize with zeros
        matrix[:] = 0
        matrix.flush()
        
        file_size = CORPUS_MATRIX_PATH.stat().st_size / (1024**3)  # GB
        logger.info(f"Matrix file created: {CORPUS_MATRIX_PATH}")
        logger.info(f"Expected file size: {file_size:.2f} GB")
        
        return matrix
    
    def encode_batch(self, texts: List[str], batch_size: int = 32) -> np.ndarray:
        """
        Encode a batch of texts to embeddings.
        
        Args:
            texts: List of text strings
            batch_size: Batch size for encoding
            
        Returns:
            Numpy array of embeddings
        """
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True  # Normalize for cosine similarity
        )
        return embeddings.astype('float32')
    
    def build_index(self, metadata_file: Path, batch_size: int = 32):
        """
        Build the complete embedding index.
        
        Args:
            metadata_file: Path to metadata JSON file
            batch_size: Batch size for encoding
        """
        logger.info("=" * 70)
        logger.info("STARTING PHASE 2: BUILDING EMBEDDING INDEX")
        logger.info("=" * 70)
        
        # Load cleaned documents
        cleaned_texts = self.load_cleaned_documents(metadata_file)
        num_docs = len(cleaned_texts)
        
        # Create memory-mapped matrix
        matrix = self.create_memory_mapped_matrix(num_docs)
        
        # Process in batches
        logger.info(f"\nEncoding {num_docs} documents in batches of {batch_size}...")
        
        num_batches = (num_docs + batch_size - 1) // batch_size
        
        with tqdm(total=num_docs, desc="Encoding documents", unit="docs") as pbar:
            for i in range(0, num_docs, batch_size):
                batch_texts = cleaned_texts[i:i+batch_size]
                
                # Encode batch
                batch_embeddings = self.encode_batch(batch_texts, batch_size)
                
                # Write to memory-mapped array
                matrix[i:i+len(batch_texts)] = batch_embeddings
                matrix.flush()  # Ensure data is written to disk
                
                pbar.update(len(batch_texts))
                
                # Log progress periodically
                if (i // batch_size) % 10 == 0:
                    logger.info(f"Processed {min(i+batch_size, num_docs)}/{num_docs} documents")
        
        # Final flush
        matrix.flush()
        
        logger.info("\n" + "=" * 70)
        logger.info("✅ PHASE 2 COMPLETE!")
        logger.info("=" * 70)
        logger.info(f"📊 Embedding matrix saved to: {CORPUS_MATRIX_PATH}")
        logger.info(f"   Shape: {matrix.shape}")
        logger.info(f"   Size: {CORPUS_MATRIX_PATH.stat().st_size / (1024**3):.2f} GB")
        logger.info(f"   dtype: {matrix.dtype}")
        
        # Verify matrix
        self.verify_index(matrix, metadata_file)
    
    def verify_index(self, matrix: np.memmap, metadata_file: Path):
        """
        Verify the index was created correctly.
        
        Args:
            matrix: Memory-mapped matrix
            metadata_file: Path to metadata JSON file
        """
        logger.info("\n🔍 Verifying index...")
        
        with open(metadata_file, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
        
        # Check shapes match
        assert len(metadata) == matrix.shape[0], "Document count mismatch!"
        
        # Check for zero vectors (shouldn't happen with normalized embeddings)
        zero_vectors = np.sum(np.linalg.norm(matrix, axis=1) < 0.1)
        if zero_vectors > 0:
            logger.warning(f"⚠️ Found {zero_vectors} zero vectors!")
        else:
            logger.info("✅ All vectors have non-zero magnitude")
        
        # Check embedding statistics
        mean_norm = np.mean(np.linalg.norm(matrix, axis=1))
        logger.info(f"📊 Vector statistics:")
        logger.info(f"   Mean norm: {mean_norm:.4f} (should be ~1.0 for normalized embeddings)")
        
        # Test similarity between first two documents
        if matrix.shape[0] >= 2:
            sim = np.dot(matrix[0], matrix[1])
            logger.info(f"   Similarity (doc0 vs doc1): {sim:.4f}")
        
        logger.info("✅ Index verification complete!")
    
    def load_existing_index(self) -> np.memmap:
        """
        Load existing memory-mapped index for queries.
        
        Returns:
            Memory-mapped numpy array (read-only)
        """
        if not CORPUS_MATRIX_PATH.exists():
            raise FileNotFoundError(f"Index not found at {CORPUS_MATRIX_PATH}. Run build_index first.")
        
        logger.info(f"Loading existing index from: {CORPUS_MATRIX_PATH}")
        matrix = np.memmap(
            str(CORPUS_MATRIX_PATH),
            dtype='float32',
            mode='r',
            shape=(self.get_num_documents(), self.embedding_dim)
        )
        
        logger.info(f"Index loaded. Shape: {matrix.shape}")
        return matrix
    
    def get_num_documents(self) -> int:
        """Get number of documents from metadata."""
        with open(METADATA_PATH, 'r', encoding='utf-8') as f:
            metadata = json.load(f)
        return len(metadata)


def main():
    """Main entry point for building the index."""
    import time
    
    start_time = time.time()
    
    # Check if metadata exists
    if not METADATA_PATH.exists():
        logger.error(f"Metadata file not found: {METADATA_PATH}")
        logger.error("Please run Phase 1 (process_my_docs.py) first!")
        return
    
    # Create indexer
    indexer = EmbeddingIndexer()
    
    # Build index
    indexer.build_index(METADATA_PATH, batch_size=32)
    
    elapsed_time = time.time() - start_time
    logger.info(f"\n⏱️ Total time: {elapsed_time:.2f} seconds ({elapsed_time/60:.2f} minutes)")


if __name__ == "__main__":
    main()