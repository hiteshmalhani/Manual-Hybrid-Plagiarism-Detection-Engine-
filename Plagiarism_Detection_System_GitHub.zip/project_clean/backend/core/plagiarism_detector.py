"""
Complete Plagiarism Detection Pipeline
"""

import sys
import time
from pathlib import Path
from typing import List, Dict
import logging

sys.path.insert(0, str(Path(__file__).parent.parent))

# Import with error handling
try:
    from core.semantic_engine import SemanticEngine
    from core.parallel_worker import ParallelLexicalWorker
    from core.cleaning import get_cleaner
    from core.config import TOP_K_RESULTS
except ImportError as e:
    print(f"Import error: {e}")
    raise

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PlagiarismDetector:
    """Complete plagiarism detection system."""
    
    def __init__(self, semantic_weight: float = 0.6, lexical_weight: float = 0.4):
        logger.info("Initializing Plagiarism Detection System...")
        
        # Check if data files exist
        from core.config import CORPUS_MATRIX_PATH, METADATA_PATH
        
        if not CORPUS_MATRIX_PATH.exists():
            raise FileNotFoundError(f"Corpus matrix not found: {CORPUS_MATRIX_PATH}")
        if not METADATA_PATH.exists():
            raise FileNotFoundError(f"Metadata not found: {METADATA_PATH}")
        
        logger.info(f"Found corpus matrix: {CORPUS_MATRIX_PATH}")
        logger.info(f"Found metadata: {METADATA_PATH}")
        
        self.semantic_engine = SemanticEngine()
        self.lexical_worker = ParallelLexicalWorker()
        self.cleaner = get_cleaner()
        self.semantic_weight = semantic_weight
        self.lexical_weight = lexical_weight
        logger.info("Plagiarism Detection System ready!")
    
    def detect_plagiarism(self, query_text: str, top_k: int = TOP_K_RESULTS) -> List[Dict]:
        start = time.time()
        
        cleaned = self.cleaner.clean_query(query_text)
        if not cleaned:
            return []
        
        # Semantic retrieval
        semantic_results = self.semantic_engine.get_top_k(query_text, k=top_k)
        if not semantic_results:
            return []
        
        # Prepare candidates
        candidates = []
        for sr in semantic_results:
            doc = self.semantic_engine.get_document_by_index(sr['index'])
            doc['semantic_score'] = sr['similarity_score']
            candidates.append(doc)
        
        # Lexical analysis
        lexical_results = self.lexical_worker.process_candidates_parallel(query_text, candidates)
        
        # Combine scores
        final = []
        for r in lexical_results:
            combined = (r.get('semantic_score', 0) * self.semantic_weight) + (r.get('lexical_score', 0) * self.lexical_weight)
            final.append({
                'file_name': r.get('file_name', 'unknown'),
                'category': r.get('category', 'unknown'),
                'semantic_score': round(r.get('semantic_score', 0), 4),
                'lexical_score': round(r.get('lexical_score', 0), 4),
                'combined_score': round(combined, 4),
                'matched_segments': r.get('matching_shingles', [])[:5],
                'num_matches': r.get('num_matches', 0)
            })
        
        final.sort(key=lambda x: x['combined_score'], reverse=True)
        logger.info(f"Detection complete in {time.time()-start:.2f}s")
        return final