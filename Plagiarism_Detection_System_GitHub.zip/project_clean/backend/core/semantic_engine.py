"""
Phase 3: Semantic Retrieval Engine - Manual vector calculations
Supports both online and offline mode
"""

import numpy as np
import json
from pathlib import Path
import logging
from typing import List, Dict
import sys
import os

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.config import CORPUS_MATRIX_PATH, METADATA_PATH, EMBEDDING_DIM, TOP_K_RESULTS
from core.cleaning import get_cleaner

# Try to import sentence_transformers
try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    print("⚠️ sentence-transformers not available")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SemanticEngine:
    """Semantic similarity search - Works online and offline"""
    
    def __init__(self):
        logger.info("Initializing Semantic Engine...")
        
        # Define local model path
        self.local_model_path = Path(__file__).parent.parent / "models" / "all-MiniLM-L6-v2"
        self.online_model_name = 'all-MiniLM-L6-v2'
        
        # Try to load model with fallback
        self.model = self._load_model()
        
        # Load corpus data
        self.corpus_matrix = self._load_corpus_matrix()
        self.metadata = self._load_metadata()
        
        logger.info(f"Semantic Engine ready. Corpus size: {self.corpus_matrix.shape[0]}")
        logger.info(f"Mode: {'OFFLINE' if self.local_model_path.exists() else 'ONLINE'}")
    
    def _load_model(self):
        """Load model with fallback: local first, then online"""
        
        # Option 1: Try local model first (OFFLINE MODE)
        if self.local_model_path.exists():
            try:
                logger.info(f"📁 Loading local model from: {self.local_model_path}")
                model = SentenceTransformer(str(self.local_model_path))
                logger.info("✅ Using OFFLINE model (no internet needed)")
                return model
            except Exception as e:
                logger.warning(f"Could not load local model: {e}")
        
        # Option 2: Try online model (ONLINE MODE)
        try:
            logger.info(f"🌐 Loading online model: {self.online_model_name}")
            model = SentenceTransformer(self.online_model_name)
            
            # Save it locally for future offline use
            logger.info("💾 Saving model locally for future offline use...")
            self.local_model_path.parent.mkdir(parents=True, exist_ok=True)
            model.save(str(self.local_model_path))
            logger.info(f"✅ Model saved to: {self.local_model_path}")
            
            return model
        except Exception as e:
            logger.error(f"Could not load model online: {e}")
            raise RuntimeError("No model available. Please ensure internet connection or download model first.")
    
    def _load_corpus_matrix(self) -> np.memmap:
        if not CORPUS_MATRIX_PATH.exists():
            raise FileNotFoundError(f"Corpus matrix not found at {CORPUS_MATRIX_PATH}")
        file_size = CORPUS_MATRIX_PATH.stat().st_size
        n_docs = file_size // (EMBEDDING_DIM * 4)
        return np.memmap(str(CORPUS_MATRIX_PATH), dtype='float32', mode='r', shape=(n_docs, EMBEDDING_DIM))
    
    def _load_metadata(self) -> List[Dict]:
        with open(METADATA_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def embed_query(self, query_text: str) -> np.ndarray:
        cleaner = get_cleaner()
        cleaned = cleaner.clean_query(query_text)
        text = ' '.join(cleaned) if cleaned else query_text
        return self.model.encode(text, convert_to_numpy=True, normalize_embeddings=True).astype('float32')
    
    def get_top_k(self, query_text: str, k: int = TOP_K_RESULTS) -> List[Dict]:
        query_vec = self.embed_query(query_text)
        scores = np.dot(self.corpus_matrix, query_vec)
        indices = np.argsort(scores)[::-1][:k]
        
        return [{
            'index': int(idx),
            'similarity_score': float(scores[idx]),
            'file_name': self.metadata[idx]['file_name'],
            'category': self.metadata[idx]['category'],
            'file_path': self.metadata[idx]['file_path'],
            'cleaned_text': self.metadata[idx]['cleaned_text']
        } for idx in indices]
    
    def get_document_by_index(self, idx: int) -> Dict:
        return self.metadata[idx]
    
    def statistics(self) -> Dict:
        return {
            'num_documents': self.corpus_matrix.shape[0],
            'categories': list(set(d['category'] for d in self.metadata)),
            'mode': 'OFFLINE' if self.local_model_path.exists() else 'ONLINE'
        }