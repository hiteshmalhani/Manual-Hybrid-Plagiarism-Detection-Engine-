﻿"""
Phase 6: Testing Suite
"""

import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from core.cleaning import TextCleaner
from core.lexical_engine import LexicalEngine


class TestPhase1Cleaning(unittest.TestCase):
    def setUp(self):
        self.cleaner = TextCleaner()
    
    def test_lowercase_conversion(self):
        text = "HELLO World"
        result = self.cleaner.clean_document(text)
        for token in result:
            self.assertTrue(token.islower())
    
    def test_stopword_removal(self):
        text = "the quick brown fox"
        result = self.cleaner.clean_document(text)
        self.assertNotIn('the', result)
        self.assertIn('quick', result)


class TestPhase4Lexical(unittest.TestCase):
    def setUp(self):
        self.engine = LexicalEngine(shingle_size=3)
    
    def test_shingle_generation(self):
        tokens = ['a', 'b', 'c', 'd']
        shingles = self.engine.generate_word_shingles(tokens)
        self.assertEqual(len(shingles), 2)
    
    def test_jaccard_range(self):
        set_a = {'a b c', 'b c d'}
        set_b = {'b c d', 'c d e'}
        result = self.engine.compute_jaccard_similarity(set_a, set_b)
        self.assertGreaterEqual(result, 0)
        self.assertLessEqual(result, 1)


if __name__ == "__main__":
    unittest.main()
