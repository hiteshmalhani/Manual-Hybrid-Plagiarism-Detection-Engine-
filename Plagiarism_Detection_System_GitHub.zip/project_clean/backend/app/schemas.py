"""
Pydantic data schemas for request/response validation.
"""

from pydantic import BaseModel
from typing import List, Optional


class QueryInput(BaseModel):
    """Input schema for plagiarism check queries."""
    text: str
    
    class Config:
        json_schema_extra = {
            "example": {
                "text": "stock market trends and financial investments"
            }
        }


class MatchDetail(BaseModel):
    """Output schema for each matching document."""
    filename: str
    category: str
    semantic_score: float
    lexical_score: float
    combined_score: float
    matched_segments: List[str]
    
    class Config:
        json_schema_extra = {
            "example": {
                "filename": "doc_10010.txt",
                "category": "Business",
                "semantic_score": 0.58,
                "lexical_score": 0.02,
                "combined_score": 0.36,
                "matched_segments": ["stock market trends"]
            }
        }


class HealthResponse(BaseModel):
    """Health check response schema."""
    status: str
    version: str
    documents_indexed: int
    detector_ready: bool