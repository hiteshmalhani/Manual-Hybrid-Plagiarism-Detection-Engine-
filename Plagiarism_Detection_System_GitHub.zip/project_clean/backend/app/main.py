"""
FastAPI application initialization and server startup.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.router import api_router

# Create FastAPI instance
app = FastAPI(
    title="Manual Hybrid Plagiarism Detection Engine",
    description="Plagiarism detection using semantic + lexical analysis",
    version="1.0.0"
)

# Configure CORS for frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API router
app.include_router(api_router)


@app.get("/")
async def root():
    """Health check endpoint."""
    return {"status": "healthy", "message": "Plagiarism Detection Engine API"}


@app.get("/api/health")
async def health_check():
    """API health check endpoint."""
    return {"status": "online", "version": "1.0.0", "documents_indexed": 20000}