"""
API endpoints - TEXT ONLY (WORKING)
"""

from fastapi import APIRouter, HTTPException
from typing import List
import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app.schemas import QueryInput, MatchDetail

# Initialize detector with detailed error logging
detector = None
try:
    from core.plagiarism_detector import PlagiarismDetector
    print("🔄 Loading Plagiarism Detector...")
    detector = PlagiarismDetector()
    print("✅ Plagiarism detector loaded successfully")
except Exception as e:
    print(f"❌ Error loading detector: {e}")
    traceback.print_exc()

api_router = APIRouter()


@api_router.post("/api/analyze", response_model=List[MatchDetail])
async def analyze_text(payload: QueryInput):
    if detector is None:
        raise HTTPException(503, "Detector not initialized. Check backend logs for details.")
    try:
        results = detector.detect_plagiarism(payload.text, top_k=5)
        return [
            MatchDetail(
                filename=r['file_name'],
                category=r['category'],
                semantic_score=r['semantic_score'],
                lexical_score=r['lexical_score'],
                combined_score=r['combined_score'],
                matched_segments=r['matched_segments']
            )
            for r in results
        ]
    except Exception as e:
        print(f"Error in analyze: {e}")
        traceback.print_exc()
        raise HTTPException(500, str(e))


@api_router.get("/api/health")
async def health():
    return {"status": "ok", "detector_ready": detector is not None}