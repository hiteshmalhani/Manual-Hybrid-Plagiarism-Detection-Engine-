# Plagiarism Detection System

A dual-engine (lexical + semantic) plagiarism detection system with web interface.

## Features
- Lexical similarity using TF-IDF and Cosine Similarity
- Semantic similarity using Sentence Transformers (all-MiniLM-L6-v2)
- Support for .txt, .pdf, and .docx files
- Real-time analysis with visual results
- 20 Newsgroups dataset included

## Installation

### Backend Setup
```bash
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt