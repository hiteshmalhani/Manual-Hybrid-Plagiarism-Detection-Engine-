import { useState, useEffect, useRef } from 'react';
import { Shield, Zap, Database, Activity, FileText, AlertCircle, CheckCircle, Award, TrendingUp, Copy, Loader2, FileSearch, Sparkles, Brain, Cpu, Clock, BookOpen, Search, BarChart3 } from 'lucide-react';

function App() {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);
  const [queryText, setQueryText] = useState('');
  const [backendStatus, setBackendStatus] = useState('checking');
  const [analysisTime, setAnalysisTime] = useState(null);
  const [displayedPercent, setDisplayedPercent] = useState(0);
  const animFrameRef = useRef(null);

  useEffect(() => {
    const checkBackend = async () => {
      try {
        const res = await fetch('http://localhost:8000/api/health');
        setBackendStatus(res.ok ? 'online' : 'offline');
      } catch {
        setBackendStatus('offline');
      }
    };
    checkBackend();
    const interval = setInterval(checkBackend, 30000);
    return () => clearInterval(interval);
  }, []);

  // Smooth needle animation
  useEffect(() => {
    const target = results && results[0] ? Math.round(results[0].combined_score * 100) : 0;
    if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    
    const start = displayedPercent;
    const duration = 1200;
    const startTime = performance.now();

    const animate = (now) => {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease out cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(start + (target - start) * eased);
      setDisplayedPercent(current);
      if (progress < 1) {
        animFrameRef.current = requestAnimationFrame(animate);
      }
    };
    animFrameRef.current = requestAnimationFrame(animate);
    return () => { if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current); };
  }, [results]);

  const analyzeText = async () => {
    if (!queryText.trim()) {
      setError('Please enter some text to analyze');
      return;
    }
    setLoading(true);
    setError(null);
    const startTime = performance.now();
    try {
      const response = await fetch('http://localhost:8000/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: queryText })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Analysis failed');
      const endTime = performance.now();
      setAnalysisTime(((endTime - startTime) / 1000).toFixed(1));
      setResults(data);
    } catch (err) {
      setError(err.message);
      setResults(null);
    } finally {
      setLoading(false);
    }
  };

  const plagiarismPercent = results && results[0] ? Math.round(results[0].combined_score * 100) : 0;
  const semanticPercent = results && results[0] ? Math.round(results[0].semantic_score * 100) : 0;
  const lexicalPercent = results && results[0] ? Math.round(results[0].lexical_score * 100) : 0;
  const originalityPercent = 100 - plagiarismPercent;

  const riskLevel = plagiarismPercent >= 70 ? 'high' : plagiarismPercent >= 40 ? 'medium' : 'low';
  const riskBgColor = riskLevel === 'high' ? 'bg-red-50 border-red-500' : riskLevel === 'medium' ? 'bg-yellow-50 border-yellow-500' : 'bg-green-50 border-green-500';
  const riskTextColor = riskLevel === 'high' ? 'text-red-700' : riskLevel === 'medium' ? 'text-yellow-700' : 'text-green-700';

  // FIXED: Smart text highlighting that actually works
  // Splits the query text into spans, highlighting any segment that matches
  const renderHighlightedText = (text, matches, combinedScore) => {
    if (!matches || matches.length === 0) {
      return <span>{text}</span>;
    }

    const isHighRisk = combinedScore >= 0.7;

    // Build a list of [start, end] ranges to highlight
    const ranges = [];
    matches.forEach(match => {
      if (!match || match.length < 4) return;
      // Case-insensitive search for all occurrences
      const lower = text.toLowerCase();
      const matchLower = match.toLowerCase();
      let idx = 0;
      while (true) {
        const pos = lower.indexOf(matchLower, idx);
        if (pos === -1) break;
        ranges.push([pos, pos + match.length]);
        idx = pos + 1;
      }
    });

    if (ranges.length === 0) {
      // Fallback: no exact matches found, try sentence-level highlighting
      // Split text into sentences and highlight sentences that contain words from matches
      const allMatchWords = new Set(
        matches.flatMap(m => m.toLowerCase().split(/\s+/).filter(w => w.length > 5))
      );
      
      const sentences = [];
      const sentenceRegex = /[^.!?]+[.!?]*/g;
      let m;
      while ((m = sentenceRegex.exec(text)) !== null) {
        const sentence = m[0];
        const sentenceLower = sentence.toLowerCase();
        const hasMatch = [...allMatchWords].some(word => sentenceLower.includes(word));
        sentences.push({ text: sentence, highlight: hasMatch });
      }

      if (sentences.some(s => s.highlight)) {
        return (
          <span>
            {sentences.map((s, i) => 
              s.highlight ? (
                <mark key={i} style={{
                  background: isHighRisk ? '#fca5a5' : '#fde047',
                  color: isHighRisk ? '#7f1d1d' : '#713f12',
                  padding: '1px 2px',
                  borderRadius: '2px',
                  fontWeight: 600,
                  borderBottom: isHighRisk ? '2px solid #dc2626' : '2px solid #ca8a04',
                }}>
                  {s.text}
                </mark>
              ) : (
                <span key={i}>{s.text}</span>
              )
            )}
          </span>
        );
      }
      return <span>{text}</span>;
    }

    // Merge overlapping ranges
    ranges.sort((a, b) => a[0] - b[0]);
    const merged = [];
    for (const r of ranges) {
      if (merged.length && r[0] <= merged[merged.length - 1][1]) {
        merged[merged.length - 1][1] = Math.max(merged[merged.length - 1][1], r[1]);
      } else {
        merged.push([...r]);
      }
    }

    // Build React nodes
    const nodes = [];
    let cursor = 0;
    merged.forEach(([start, end], i) => {
      if (cursor < start) nodes.push(<span key={`t${i}`}>{text.slice(cursor, start)}</span>);
      nodes.push(
        <mark key={`h${i}`} style={{
          background: isHighRisk ? '#fca5a5' : '#fde047',
          color: isHighRisk ? '#7f1d1d' : '#713f12',
          padding: '1px 3px',
          borderRadius: '3px',
          fontWeight: 600,
          borderBottom: isHighRisk ? '2px solid #dc2626' : '2px solid #ca8a04',
        }}>
          {text.slice(start, end)}
        </mark>
      );
      cursor = end;
    });
    if (cursor < text.length) nodes.push(<span key="tail">{text.slice(cursor)}</span>);
    return <>{nodes}</>;
  };

  // Speedometer geometry helpers
  const polarToXY = (angleDeg, r, cx = 140, cy = 140) => {
    const rad = (angleDeg * Math.PI) / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  };

  // Arc: angle -180 (left) to 0 (right), mapping 0%→-180°, 100%→0°
  const percentToAngle = (pct) => -180 + (pct / 100) * 180;

  const describeArc = (startPct, endPct, r, cx = 140, cy = 140) => {
    const a1 = percentToAngle(startPct);
    const a2 = percentToAngle(endPct);
    const p1 = polarToXY(a1, r, cx, cy);
    const p2 = polarToXY(a2, r, cx, cy);
    const largeArc = (endPct - startPct) > 50 ? 1 : 0;
    return `M ${p1.x} ${p1.y} A ${r} ${r} 0 ${largeArc} 1 ${p2.x} ${p2.y}`;
  };

  const needleAngle = percentToAngle(displayedPercent);
  const needleRad = (needleAngle * Math.PI) / 180;
  const needleTipX = 140 + 88 * Math.cos(needleRad);
  const needleTipY = 140 + 88 * Math.sin(needleRad);
  const needleBase1X = 140 + 11 * Math.cos(needleRad + Math.PI / 2);
  const needleBase1Y = 140 + 11 * Math.sin(needleRad + Math.PI / 2);
  const needleBase2X = 140 + 11 * Math.cos(needleRad - Math.PI / 2);
  const needleBase2Y = 140 + 11 * Math.sin(needleRad - Math.PI / 2);

  const dotPos = polarToXY(needleAngle, 112);
  const dotColor = riskLevel === 'high' ? '#ef4444' : riskLevel === 'medium' ? '#f59e0b' : '#10b981';
  const gaugeColor = riskLevel === 'high' ? '#ef4444' : riskLevel === 'medium' ? '#f59e0b' : '#10b981';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-indigo-600 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl shadow-lg">
                <Shield className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  PlagiScan Pro
                </h1>
                <p className="text-xs text-gray-500">AI-Powered Plagiarism Detection Engine</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex gap-2 text-xs">
                <div className="px-3 py-1.5 bg-indigo-50 rounded-full flex items-center gap-1"><Database className="w-3.5 h-3.5 text-indigo-600" />20K Docs</div>
                <div className="px-3 py-1.5 bg-purple-50 rounded-full flex items-center gap-1"><Brain className="w-3.5 h-3.5 text-purple-600" />384-dim AI</div>
                <div className="px-3 py-1.5 bg-emerald-50 rounded-full flex items-center gap-1"><Cpu className="w-3.5 h-3.5 text-emerald-600" />Parallel</div>
              </div>
              <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium ${backendStatus === 'online' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                <div className={`w-2 h-2 rounded-full ${backendStatus === 'online' ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
                {backendStatus === 'online' ? 'System Online' : 'Offline'}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white py-10">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 bg-white/20 rounded-full px-4 py-1.5 mb-4 backdrop-blur-sm">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-medium">AI-Powered Detection</span>
          </div>
          <h2 className="text-3xl font-bold mb-2">Check Plagiarism Instantly</h2>
          <p className="text-indigo-100">Paste your text below and get detailed analysis in seconds</p>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-6 py-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Panel */}
          <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
            <div className="p-5 bg-gradient-to-r from-indigo-50 to-purple-50 border-b">
              <h3 className="font-semibold flex items-center gap-2 text-lg">
                <FileText className="w-5 h-5 text-indigo-600" />
                Text to Analyze
              </h3>
              <p className="text-sm text-gray-500 mt-1">Paste your content below</p>
            </div>
            <div className="p-5">
              <textarea
                value={queryText}
                onChange={(e) => setQueryText(e.target.value)}
                placeholder="Paste your text here (minimum 50 characters)..."
                className="w-full h-80 p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-y font-mono text-sm bg-gray-50"
                disabled={loading}
              />
              {error && (
                <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2">
                  <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              )}
              <button
                onClick={analyzeText}
                disabled={loading || !queryText.trim()}
                className="mt-5 w-full py-3.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 disabled:opacity-50 transition-all font-semibold shadow-lg hover:shadow-xl transform hover:scale-[1.02]"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Analyzing Content...
                  </span>
                ) : (
                  <span className="flex items-center justify-center gap-2">
                    <Search className="w-5 h-5" />
                    Check Plagiarism
                  </span>
                )}
              </button>
              <div className="mt-4 flex items-center justify-center gap-4 text-xs text-gray-400">
                <span className="flex items-center gap-1"><Clock className="w-3 h-3" />2-5 seconds</span>
                <span className="flex items-center gap-1"><Brain className="w-3 h-3" />AI-powered</span>
                <span className="flex items-center gap-1"><Database className="w-3 h-3" />20K documents</span>
              </div>
            </div>
          </div>

          {/* Right Panel */}
          <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
            <div className="p-5 bg-gray-50 border-b">
              <h2 className="font-semibold flex items-center gap-2 text-lg">
                <BarChart3 className="w-5 h-5 text-indigo-600" />
                Analysis Results
              </h2>
              {analysisTime && (
                <p className="text-xs text-gray-500 mt-1">Completed in {analysisTime}s</p>
              )}
            </div>
            <div className="p-5 max-h-[750px] overflow-y-auto">
              {loading ? (
                <div className="text-center py-16">
                  <div className="relative w-20 h-20 mx-auto">
                    <div className="absolute inset-0 border-4 border-indigo-200 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-indigo-600 rounded-full border-t-transparent animate-spin"></div>
                  </div>
                  <p className="mt-4 text-gray-600 font-medium">Scanning 20,000 documents...</p>
                  <p className="text-sm text-gray-400 mt-1">Using semantic + lexical analysis</p>
                </div>
              ) : results && results.length > 0 ? (
                <>
                  {/* Risk Banner */}
                  <div className={`${riskBgColor} border-2 rounded-xl p-4 mb-5 text-center`}>
                    <div className="flex items-center justify-center gap-3 mb-1">
                      {riskLevel === 'low'
                        ? <CheckCircle className="w-7 h-7 text-green-600" />
                        : <AlertCircle className={`w-7 h-7 ${riskLevel === 'high' ? 'text-red-600' : 'text-yellow-600'}`} />
                      }
                      <span className={`text-lg font-bold ${riskTextColor}`}>
                        {riskLevel === 'high' ? '⚠️ High Risk — Plagiarism Detected'
                          : riskLevel === 'medium' ? '🟡 Medium Risk — Similar Content Found'
                          : '✅ Low Risk — Original Content'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">
                      {plagiarismPercent >= 70
                        ? `Your content is ${plagiarismPercent}% similar to existing sources.`
                        : plagiarismPercent >= 40
                        ? `Your content shows ${plagiarismPercent}% similarity. Review suggested.`
                        : `Your content appears ${originalityPercent}% original!`}
                    </p>
                  </div>

                  {/* ── FIXED SPEEDOMETER ── */}
                  <div className="rounded-2xl p-5 mb-5 shadow-inner" style={{background:'#0f172a'}}>
                    <p className="text-center text-xs font-semibold tracking-widest uppercase mb-3" style={{color:'rgba(255,255,255,0.5)'}}>Plagiarism Risk Meter</p>

                    <svg width="100%" viewBox="0 0 280 165" xmlns="http://www.w3.org/2000/svg">
                      {/* Track shadow */}
                      <path d={describeArc(0, 100, 112)} fill="none" stroke="#1e293b" strokeWidth="22" strokeLinecap="round"/>

                      {/* Colored zones */}
                      <path d={describeArc(0, 40, 112)}   fill="none" stroke="#10b981" strokeWidth="16" strokeLinecap="butt" opacity="0.9"/>
                      <path d={describeArc(40, 70, 112)}  fill="none" stroke="#f59e0b" strokeWidth="16" strokeLinecap="butt" opacity="0.9"/>
                      <path d={describeArc(70, 100, 112)} fill="none" stroke="#ef4444" strokeWidth="16" strokeLinecap="round" opacity="0.9"/>

                      {/* Active fill up to current score */}
                      <path d={describeArc(0, Math.max(displayedPercent, 1), 112)} fill="none" stroke={gaugeColor} strokeWidth="4" strokeLinecap="round" opacity="0.6"/>

                      {/* Score dot on track */}
                      <circle cx={dotPos.x} cy={dotPos.y} r="9" fill={dotColor} stroke="white" strokeWidth="2.5"/>

                      {/* Tick marks */}
                      {[0,10,20,30,40,50,60,70,80,90,100].map(val => {
                        const ang = percentToAngle(val);
                        const rad = (ang * Math.PI) / 180;
                        const isMajor = val % 20 === 0;
                        const r1 = isMajor ? 94 : 99;
                        const r2 = 107;
                        return (
                          <line key={val}
                            x1={140 + r1 * Math.cos(rad)} y1={140 + r1 * Math.sin(rad)}
                            x2={140 + r2 * Math.cos(rad)} y2={140 + r2 * Math.sin(rad)}
                            stroke={isMajor ? 'rgba(255,255,255,0.55)' : 'rgba(255,255,255,0.2)'}
                            strokeWidth={isMajor ? 2 : 1} strokeLinecap="round"
                          />
                        );
                      })}

                      {/* Needle */}
                      <polygon
                        points={`${needleTipX},${needleTipY} ${needleBase1X},${needleBase1Y} ${needleBase2X},${needleBase2Y}`}
                        fill="white" opacity="0.92"
                      />
                      {/* Tail */}
                      <circle cx={140 + 14 * Math.cos(needleRad + Math.PI)} cy={140 + 14 * Math.sin(needleRad + Math.PI)} r="4" fill={gaugeColor}/>

                      {/* Center hub */}
                      <circle cx="140" cy="140" r="15" fill="#1e293b" stroke="rgba(255,255,255,0.15)" strokeWidth="1.5"/>
                      <circle cx="140" cy="140" r="9" fill={gaugeColor}/>
                      <circle cx="140" cy="140" r="3.5" fill="white" opacity="0.9"/>

                      {/* Score */}
                      <text x="140" y="105" textAnchor="middle" fill="white" fontSize="34" fontWeight="800" fontFamily="monospace" letterSpacing="-1">
                        {displayedPercent}%
                      </text>
                      <text x="140" y="120" textAnchor="middle" fill="rgba(255,255,255,0.45)" fontSize="9" letterSpacing="2.5" fontFamily="sans-serif">
                        PLAGIARISM
                      </text>

                      {/* Zone labels */}
                      <text x="32" y="155" textAnchor="middle" fill="#10b981" fontSize="9" fontWeight="600">Original</text>
                      <text x="140" y="32" textAnchor="middle" fill="#f59e0b" fontSize="9" fontWeight="600">Moderate</text>
                      <text x="248" y="155" textAnchor="middle" fill="#ef4444" fontSize="9" fontWeight="600">Plagiarized</text>
                    </svg>

                    {/* Risk badge */}
                    <div className={`mt-1 mx-auto w-fit px-5 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase ${
                      riskLevel === 'high' ? 'text-red-300 border border-red-500/40' 
                      : riskLevel === 'medium' ? 'text-yellow-300 border border-yellow-500/40' 
                      : 'text-emerald-300 border border-emerald-500/40'}`}
                      style={{background: riskLevel === 'high' ? 'rgba(239,68,68,0.15)' : riskLevel === 'medium' ? 'rgba(245,158,11,0.15)' : 'rgba(16,185,129,0.15)'}}>
                      {riskLevel === 'high' ? '⚠ High Risk' : riskLevel === 'medium' ? '⚡ Medium Risk' : '✓ Low Risk'}
                    </div>
                  </div>

                  {/* Score Cards */}
                  <div className="grid grid-cols-3 gap-3 mb-5">
                    <div className="bg-blue-50 rounded-xl p-3 text-center">
                      <TrendingUp className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                      <div className="text-2xl font-bold text-blue-600">{semanticPercent}%</div>
                      <div className="text-xs text-gray-500">Semantic</div>
                    </div>
                    <div className="bg-purple-50 rounded-xl p-3 text-center">
                      <Copy className="w-5 h-5 text-purple-600 mx-auto mb-1" />
                      <div className="text-2xl font-bold text-purple-600">{lexicalPercent}%</div>
                      <div className="text-xs text-gray-500">Lexical</div>
                    </div>
                    <div className={`rounded-xl p-3 text-center ${riskLevel === 'high' ? 'bg-red-50' : riskLevel === 'medium' ? 'bg-yellow-50' : 'bg-green-50'}`}>
                      <Award className={`w-5 h-5 mx-auto mb-1 ${riskLevel === 'high' ? 'text-red-600' : riskLevel === 'medium' ? 'text-yellow-600' : 'text-green-600'}`} />
                      <div className={`text-2xl font-bold ${riskLevel === 'high' ? 'text-red-600' : riskLevel === 'medium' ? 'text-yellow-600' : 'text-green-600'}`}>{plagiarismPercent}%</div>
                      <div className="text-xs text-gray-500">Combined</div>
                    </div>
                  </div>

                  {/* Top Matches */}
                  <div className="mb-5">
                    <h3 className="font-semibold mb-3 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-indigo-600" />
                      Top Matching Sources
                    </h3>
                    {results.slice(0, 5).map((r, i) => (
                      <div key={i} className="mb-3">
                        <div className="flex justify-between text-sm mb-1">
                          <span className="font-medium truncate max-w-[200px]">{r.filename}</span>
                          <span className="font-bold">{(r.combined_score * 100).toFixed(1)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div className={`h-2.5 rounded-full transition-all duration-1000 ${r.combined_score >= 0.7 ? 'bg-red-500' : r.combined_score >= 0.4 ? 'bg-yellow-500' : 'bg-green-500'}`}
                            style={{ width: `${r.combined_score * 100}%` }} />
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* ── FIXED: Text Highlighting ── */}
                  {queryText && (
                    <div className="mb-5 p-4 bg-amber-50 rounded-xl border border-amber-200">
                      <h3 className="font-semibold text-sm text-amber-800 mb-2 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4" />
                        Your Text with Detected Matches
                      </h3>
                      <div className="text-sm text-gray-700 leading-relaxed bg-white p-4 rounded-lg max-h-64 overflow-y-auto">
                        {results[0]?.matched_segments && results[0].matched_segments.length > 0 ? (
                          renderHighlightedText(queryText, results[0].matched_segments, results[0].combined_score)
                        ) : results[0]?.combined_score >= 0.4 ? (
                          // If high score but no segment data, highlight whole text
                          <mark style={{
                            background: results[0].combined_score >= 0.7 ? '#fca5a5' : '#fde047',
                            color: results[0].combined_score >= 0.7 ? '#7f1d1d' : '#713f12',
                            padding: '1px 2px', borderRadius: '2px', fontWeight: 600,
                            borderBottom: results[0].combined_score >= 0.7 ? '2px solid #dc2626' : '2px solid #ca8a04',
                          }}>{queryText}</mark>
                        ) : (
                          <span className="text-gray-600">{queryText}</span>
                        )}
                      </div>
                      <div className="text-xs text-gray-500 mt-2 flex flex-wrap items-center gap-3">
                        <span className="flex items-center gap-1.5">
                          <span style={{background:'#fde047', border:'2px solid #ca8a04'}} className="inline-block w-4 h-3 rounded" />
                          <b>Yellow</b> = Medium risk (40–69%)
                        </span>
                        <span className="flex items-center gap-1.5">
                          <span style={{background:'#fca5a5', border:'2px solid #dc2626'}} className="inline-block w-4 h-3 rounded" />
                          <b>Red</b> = High risk (≥70%)
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Detailed Matches */}
                  <div className="space-y-3">
                    <h3 className="font-semibold text-sm flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-purple-600" />
                      Detailed Match Analysis
                    </h3>
                    {results.map((match, idx) => (
                      <div key={idx} className="bg-gray-50 rounded-xl p-4 border border-gray-200 hover:shadow-md transition-all">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <div className="font-semibold text-gray-800">{match.filename}</div>
                            <div className="text-xs text-gray-500">{match.category}</div>
                          </div>
                          <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${match.combined_score >= 0.7 ? 'bg-red-100 text-red-700' : match.combined_score >= 0.4 ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                            Match #{idx + 1}
                          </span>
                        </div>
                        <div className="grid grid-cols-3 gap-2 text-center text-xs mb-3">
                          <div className="p-2 bg-white rounded-lg"><div className="text-gray-500">Semantic</div><div className="font-bold text-indigo-600">{(match.semantic_score * 100).toFixed(1)}%</div></div>
                          <div className="p-2 bg-white rounded-lg"><div className="text-gray-500">Lexical</div><div className="font-bold text-purple-600">{(match.lexical_score * 100).toFixed(1)}%</div></div>
                          <div className="p-2 bg-white rounded-lg"><div className="text-gray-500">Combined</div><div className={`font-bold ${match.combined_score >= 0.7 ? 'text-red-600' : match.combined_score >= 0.4 ? 'text-yellow-600' : 'text-green-600'}`}>{(match.combined_score * 100).toFixed(1)}%</div></div>
                        </div>
                        {match.matched_segments?.length > 0 && (
                          <div className="p-2 bg-amber-50 rounded-lg text-xs border border-amber-200">
                            <span className="text-amber-700 font-medium">Exact match found:</span>
                            <span className="ml-2 font-mono text-red-700 bg-yellow-200 px-1 rounded">"{match.matched_segments[0]}"</span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-center py-16">
                  <div className="w-20 h-20 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <FileSearch className="w-10 h-10 text-indigo-500" />
                  </div>
                  <p className="text-gray-500 font-medium">No analysis performed yet</p>
                  <p className="text-sm text-gray-400 mt-1">Enter text and click "Check Plagiarism"</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-white border-t mt-12 py-6">
        <div className="max-w-7xl mx-auto px-6 text-center text-sm text-gray-500">
          <p>⚡ PlagiScan Pro | AI-Powered Plagiarism Detection</p>
          <p className="text-xs mt-1">Semantic Similarity + Lexical Analysis | 20,000+ Documents Indexed</p>
        </div>
      </footer>
    </div>
  );
}

export default App;