import { useState } from 'react';
import { checkPlagiarism } from '../services/api';

export const usePlagiarismCheck = () => {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState(null);

  const analyzeText = async (text) => {
    if (!text.trim()) {
      setError('Please enter some text to analyze');
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const data = await checkPlagiarism(text);
      
      // If no results or empty results
      if (!data || data.length === 0) {
        setResults([]);
      } else {
        setResults(data);
      }
    } catch (err) {
      console.error('Analysis error:', err);
      setError(err.response?.data?.detail || 'Failed to analyze text. Please make sure the backend is running.');
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const clearResults = () => {
    setResults(null);
    setError(null);
  };

  return { analyzeText, loading, results, error, clearResults };
};