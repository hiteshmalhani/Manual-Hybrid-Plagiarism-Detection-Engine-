export const PlagiarismChart = ({ results }) => {
  if (!results || results.length === 0) return null;

  const maxScore = Math.max(...results.map(r => r.combined_score));
  const avgScore = results.reduce((a, b) => a + b.combined_score, 0) / results.length;

  return (
    <div className="bg-white rounded-lg border p-4 mb-4">
      <h3 className="font-semibold mb-3">Plagiarism Analysis</h3>
      <div className="space-y-3">
        {results.slice(0, 5).map((result, idx) => (
          <div key={idx}>
            <div className="flex justify-between text-sm mb-1">
              <span className="truncate max-w-[200px]">{result.filename}</span>
              <span className="font-bold">{(result.combined_score * 100).toFixed(1)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all ${result.combined_score >= 0.7 ? 'bg-red-500' : result.combined_score >= 0.4 ? 'bg-yellow-500' : 'bg-green-500'}`} 
                style={{ width: `${result.combined_score * 100}%` }} 
              />
            </div>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-3 gap-3 mt-4 pt-3 border-t">
        <div className="text-center">
          <div className="text-2xl font-bold text-red-600">{(maxScore * 100).toFixed(1)}%</div>
          <div className="text-xs text-gray-500">Highest Match</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-yellow-600">{(avgScore * 100).toFixed(1)}%</div>
          <div className="text-xs text-gray-500">Average Match</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">{results.length}</div>
          <div className="text-xs text-gray-500">Matches Found</div>
        </div>
      </div>
    </div>
  );
};