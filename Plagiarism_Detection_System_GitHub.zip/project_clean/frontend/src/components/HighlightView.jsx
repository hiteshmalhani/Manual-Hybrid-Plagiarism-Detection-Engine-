import { useState } from 'react';
import { ChevronLeft, ChevronRight, AlertTriangle, CheckCircle } from 'lucide-react';

export const HighlightView = ({ queryText, matches }) => {
  const [selectedMatch, setSelectedMatch] = useState(0);

  if (!matches || matches.length === 0) {
    return (
      <div className="bg-green-50 rounded-lg border border-green-200 p-6 text-center">
        <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
        <p className="text-green-700 font-medium">No plagiarism detected!</p>
        <p className="text-sm text-gray-600 mt-1">This appears to be original content</p>
      </div>
    );
  }

  const currentMatch = matches[selectedMatch];
  const isHighRisk = currentMatch.combined_score >= 0.7;
  const isMediumRisk = currentMatch.combined_score >= 0.4 && currentMatch.combined_score < 0.7;

  const highlightText = (text, matchSegments) => {
    if (!matchSegments || matchSegments.length === 0) return text;
    let highlighted = text;
    matchSegments.forEach(segment => {
      const regex = new RegExp(`(${segment.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      highlighted = highlighted.replace(regex, '<mark class="bg-red-200 text-red-800 px-0.5 rounded font-bold">$1</mark>');
    });
    return <span dangerouslySetInnerHTML={{ __html: highlighted }} />;
  };

  return (
    <div className="space-y-4">
      <div className={`p-4 rounded-lg ${isHighRisk ? 'bg-red-50 border-red-200' : isMediumRisk ? 'bg-yellow-50 border-yellow-200' : 'bg-green-50 border-green-200'} border`}>
        <div className="flex items-center gap-3">
          {isHighRisk && <AlertTriangle className="w-6 h-6 text-red-600" />}
          <div>
            <h3 className={`font-bold ${isHighRisk ? 'text-red-700' : isMediumRisk ? 'text-yellow-700' : 'text-green-700'}`}>
              {isHighRisk ? 'High Risk - Plagiarism Detected' : isMediumRisk ? 'Medium Risk - Similar Content Found' : 'Low Risk - Original Content'}
            </h3>
            <p className="text-sm">Combined similarity: {(currentMatch.combined_score * 100).toFixed(1)}%</p>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between bg-white rounded-lg border p-3">
        <button 
          onClick={() => setSelectedMatch(Math.max(0, selectedMatch - 1))} 
          disabled={selectedMatch === 0}
          className="p-1 rounded hover:bg-gray-100 disabled:opacity-50"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="text-center">
          <span className="font-semibold">{selectedMatch + 1}</span>
          <span className="text-gray-500"> / {matches.length}</span>
          <div className="text-sm text-gray-600">{currentMatch.filename}</div>
        </div>
        <button 
          onClick={() => setSelectedMatch(Math.min(matches.length - 1, selectedMatch + 1))} 
          disabled={selectedMatch === matches.length - 1}
          className="p-1 rounded hover:bg-gray-100 disabled:opacity-50"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      <div className="bg-blue-50 rounded-lg border border-blue-200 p-4">
        <div className="text-sm font-medium text-blue-800 mb-2">Your Query:</div>
        <div className="text-blue-900 leading-relaxed">{highlightText(queryText, currentMatch.matched_segments)}</div>
      </div>

      <div className="flex gap-4 text-xs">
        <div className="flex items-center gap-1">
          <span className="bg-red-200 w-4 h-4 rounded"></span>
          <span>Exact verbatim match (Red)</span>
        </div>
      </div>
    </div>
  );
};