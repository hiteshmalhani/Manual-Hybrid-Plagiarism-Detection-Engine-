import { TrendingUp, Copy, Award, AlertTriangle, CheckCircle } from 'lucide-react';

export const ScoreCard = ({ semantic, lexical, combined }) => {
  const getScoreColor = (score, type) => {
    if (score >= 0.7) return 'bg-red-500';
    if (score >= 0.4) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getScoreIcon = (score) => {
    if (score >= 0.7) return <AlertTriangle className="w-5 h-5" />;
    if (score >= 0.4) return <AlertTriangle className="w-5 h-5" />;
    return <CheckCircle className="w-5 h-5" />;
  };

  return (
    <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-xl shadow-lg p-6 text-white">
      <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
        <Award className="w-5 h-5 text-yellow-400" />
        Similarity Analysis
      </h3>
      
      <div className="grid grid-cols-3 gap-4">
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 mb-2">
            <TrendingUp className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-gray-300">Semantic</span>
          </div>
          <div className="text-3xl font-bold text-blue-400">{(semantic * 100).toFixed(1)}%</div>
          <div className="w-full bg-gray-700 rounded-full h-1 mt-2">
            <div className={`h-1 rounded-full bg-blue-500`} style={{ width: `${semantic * 100}%` }} />
          </div>
          <p className="text-xs text-gray-400 mt-1">Meaning similarity</p>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 mb-2">
            <Copy className="w-4 h-4 text-purple-400" />
            <span className="text-sm text-gray-300">Lexical</span>
          </div>
          <div className="text-3xl font-bold text-purple-400">{(lexical * 100).toFixed(1)}%</div>
          <div className="w-full bg-gray-700 rounded-full h-1 mt-2">
            <div className={`h-1 rounded-full bg-purple-500`} style={{ width: `${lexical * 100}%` }} />
          </div>
          <p className="text-xs text-gray-400 mt-1">Verbatim match</p>
        </div>
        
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 mb-2">
            <Award className="w-4 h-4 text-yellow-400" />
            <span className="text-sm text-gray-300">Combined</span>
          </div>
          <div className="text-3xl font-bold text-yellow-400">{(combined * 100).toFixed(1)}%</div>
          <div className="w-full bg-gray-700 rounded-full h-1 mt-2">
            <div 
              className={`h-1 rounded-full ${combined >= 0.7 ? 'bg-red-500' : combined >= 0.4 ? 'bg-yellow-500' : 'bg-green-500'}`} 
              style={{ width: `${combined * 100}%` }} 
            />
          </div>
          <p className="text-xs text-gray-400 mt-1">Final score</p>
        </div>
      </div>
      
      <div className="mt-4 pt-3 border-t border-gray-700 text-center">
        <p className="text-sm">
          {combined >= 0.7 ? (
            <span className="text-red-400">⚠️ High plagiarism detected - Consider citing sources</span>
          ) : combined >= 0.4 ? (
            <span className="text-yellow-400">🟡 Moderate similarity found - Review matched content</span>
          ) : (
            <span className="text-green-400">✅ Content appears original - No significant plagiarism detected</span>
          )}
        </p>
      </div>
    </div>
  );
};