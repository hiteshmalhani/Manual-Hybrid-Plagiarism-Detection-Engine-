import { useState, useRef } from 'react';
import { Upload, FileText, X, CheckCircle, AlertCircle, Loader2, File, FileArchive } from 'lucide-react';

export const FileUploader = ({ onFileProcessed }) => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [fileContent, setFileContent] = useState(null);
  const fileInputRef = useRef(null);

  const supportedFormats = [
    { ext: '.txt', name: 'Text Files', icon: FileText },
    { ext: '.pdf', name: 'PDF Documents', icon: File },
    { ext: '.docx', name: 'Word Documents', icon: File },
    { ext: '.md', name: 'Markdown', icon: FileText },
    { ext: '.html', name: 'HTML Files', icon: FileArchive },
    { ext: '.rtf', name: 'Rich Text', icon: FileText },
  ];

  const allowedTypes = ['.txt', '.pdf', '.docx', '.md', '.html', '.rtf'];
  const maxSize = 10 * 1024 * 1024; // 10MB

  const handleFileSelect = (event) => {
    const selectedFile = event.target.files[0];
    setError(null);
    setSuccess(null);
    setFileContent(null);
    
    if (!selectedFile) return;
    
    const fileExt = '.' + selectedFile.name.split('.').pop().toLowerCase();
    if (!allowedTypes.includes(fileExt)) {
      setError(`Unsupported file type. Supported: ${allowedTypes.join(', ')}`);
      return;
    }
    
    if (selectedFile.size > maxSize) {
      setError(`File too large. Max size: 10MB (Your file: ${(selectedFile.size / 1024 / 1024).toFixed(1)}MB)`);
      return;
    }
    
    setFile(selectedFile);
  };

  const handleUpload = async () => {
    if (!file) return;
    
    setUploading(true);
    setUploadProgress(0);
    setError(null);
    
    const formData = new FormData();
    formData.append('file', file);
    
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => Math.min(prev + 10, 90));
    }, 200);
    
    try {
      const response = await fetch('http://localhost:8000/api/analyze-file', {
        method: 'POST',
        body: formData
      });
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Upload failed');
      }
      
      const results = await response.json();
      
      // Get extracted text preview
      const extractResponse = await fetch('http://localhost:8000/api/extract-file', {
        method: 'POST',
        body: formData
      });
      
      let extractedText = '';
      if (extractResponse.ok) {
        const extractData = await extractResponse.json();
        extractedText = extractData.extracted_text_preview;
        setFileContent(extractData.extracted_text_preview);
      }
      
      setSuccess(`✅ File processed! Found ${results.length} potential matches.`);
      onFileProcessed(results, extractedText);
      
      setTimeout(() => setSuccess(null), 5000);
      
    } catch (err) {
      setError(err.message);
      setTimeout(() => setError(null), 5000);
    } finally {
      clearInterval(progressInterval);
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const clearFile = () => {
    setFile(null);
    setError(null);
    setSuccess(null);
    setFileContent(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const getFileIcon = () => {
    if (!file) return Upload;
    const ext = '.' + file.name.split('.').pop().toLowerCase();
    const format = supportedFormats.find(f => f.ext === ext);
    return format?.icon || FileText;
  };

  const FileIcon = getFileIcon();

  return (
    <div className="bg-white rounded-xl shadow-lg border overflow-hidden">
      <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 border-b">
        <h3 className="font-semibold flex items-center gap-2">
          <Upload className="w-5 h-5 text-purple-600" />
          Upload Document
        </h3>
        <p className="text-xs text-gray-500 mt-1">Supported: PDF, DOCX, TXT, MD, HTML, RTF (Max 10MB)</p>
      </div>
      
      <div className="p-6">
        <div 
          className={`border-2 border-dashed rounded-xl p-8 text-center transition-all ${
            file ? 'border-green-400 bg-green-50' : 'border-gray-300 hover:border-purple-400 hover:bg-purple-50'
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            onChange={handleFileSelect}
            accept=".txt,.pdf,.docx,.md,.html,.rtf"
            className="hidden"
            id="file-upload"
          />
          
          {!file ? (
            <>
              <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">Drag & drop or click to upload</p>
              <div className="flex flex-wrap justify-center gap-2 mt-3">
                {supportedFormats.map(format => (
                  <span key={format.ext} className="text-xs px-2 py-1 bg-gray-100 rounded-full text-gray-600">
                    {format.ext}
                  </span>
                ))}
              </div>
              <button
                onClick={() => fileInputRef.current.click()}
                className="mt-4 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-all shadow-md"
              >
                Select File
              </button>
            </>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-white rounded-lg shadow-sm">
                <div className="flex items-center gap-3">
                  <FileIcon className="w-10 h-10 text-purple-600" />
                  <div className="text-left">
                    <p className="font-medium text-gray-800">{file.name}</p>
                    <p className="text-xs text-gray-500">
                      {(file.size / 1024).toFixed(1)} KB
                    </p>
                  </div>
                </div>
                <button
                  onClick={clearFile}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
              
              {fileContent && (
                <div className="text-left p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500 mb-1">📄 Extracted Preview:</p>
                  <p className="text-sm text-gray-700 line-clamp-3">{fileContent.substring(0, 200)}...</p>
                </div>
              )}
              
              {uploading && (
                <div className="space-y-2">
                  <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-gradient-to-r from-purple-600 to-blue-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${uploadProgress}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500">Processing... {uploadProgress}%</p>
                </div>
              )}
              
              <button
                onClick={handleUpload}
                disabled={uploading}
                className="w-full py-3 bg-gradient-to-r from-green-600 to-teal-600 text-white rounded-lg hover:from-green-700 hover:to-teal-700 disabled:opacity-50 transition-all flex items-center justify-center gap-2 font-medium shadow-md"
              >
                {uploading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <CheckCircle className="w-5 h-5" />
                )}
                {uploading ? 'Processing Document...' : '🔍 Check for Plagiarism'}
              </button>
            </div>
          )}
        </div>
        
        {error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}
        
        {success && (
          <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <p className="text-sm text-green-700">{success}</p>
          </div>
        )}
      </div>
    </div>
  );
};