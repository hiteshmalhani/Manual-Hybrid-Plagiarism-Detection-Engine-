import { FileText, FolderOpen, Copy, TrendingUp, Award } from 'lucide-react';

export const MatchMetadata = ({ match, index }) => {
  const getScoreBadge = (score) => {
    if (score >= 0.7) return { bg: 'bg-red-100', text: 'text-red-700', label: 'High Match' };
    if (score >= 0.4) return { bg: 'bg-yellow-100', text: 'text-yellow-700', label: 'Medium Match' };
    return { bg: 'bg-green-100', text: 'text-green-700', label: 'Low Match' };
  };

  const badge = getScoreBadge(match.combined_score);

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-all hover:border-blue-300">
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <FileText className="w-4 h-4 text-blue-600" />
            <h3 className="font-semibold text-gray-900">{match.filename}</h3>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <FolderOpen className="w-3 h-3" />
            <span>{match.category || 'General'}</span>
          </div>
        </div>
        <div className="text-right">
          <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${badge.bg} ${badge.text}`}>
            #{index + 1} - {badge.label}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-3">
        <div className="text-center p-2 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-center gap-1 text-xs text-gray-500">
            <TrendingUp className="w-3 h-3" />
            <span>Semantic</span>
          </div>
          <div className="font-bold text-blue-600">{(match.semantic_score * 100).toFixed(1)}%</div>
        </div>
        <div className="text-center p-2 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-center gap-1 text-xs text-gray-500">
            <Copy className="w-3 h-3" />
            <span>Lexical</span>
          </div>
          <div className="font-bold text-purple-600">{(match.lexical_score * 100).toFixed(1)}%</div>
        </div>
        <div className="text-center p-2 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-center gap-1 text-xs text-gray-500">
            <Award className="w-3 h-3" />
            <span>Combined</span>
          </div>
          <div className={`font-bold ${match.combined_score >= 0.7 ? 'text-red-600' : match.combined_score >= 0.4 ? 'text-yellow-600' : 'text-green-600'}`}>
            {(match.combined_score * 100).toFixed(1)}%
          </div>
        </div>
      </div>

      {match.matched_segments && match.matched_segments.length > 0 && (
        <div className="mt-2 pt-2 border-t border-gray-100">
          <div className="flex items-center gap-1 text-xs text-gray-500 mb-2">
            <Copy className="w-3 h-3" />
            <span>Matching phrases ({match.num_matches} found):</span>
          </div>
          <div className="flex flex-wrap gap-1">
            {match.matched_segments.slice(0, 3).map((segment, i) => (
              <span key={i} className="text-xs bg-red-50 text-red-700 px-2 py-1 rounded">
                "{segment}"
              </span>
            ))}
            {match.matched_segments.length > 3 && (
              <span className="text-xs text-gray-500">+{match.matched_segments.length - 3} more</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};