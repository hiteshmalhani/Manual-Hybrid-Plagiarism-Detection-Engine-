import { useState } from 'react';
import { Send, AlertCircle, FileText } from 'lucide-react';

export const TextInput = ({ onSubmit, loading, error }) => {
  const [text, setText] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (text.trim()) {
      onSubmit(text);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border">
      <div className="p-4 border-b">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <FileText className="w-5 h-5 text-blue-600" />
          Text to Analyze
        </h2>
        <p className="text-sm text-gray-600 mt-1">Paste text to check for plagiarism</p>
      </div>
      
      <form onSubmit={handleSubmit} className="p-4">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Enter your text here..."
          className="w-full h-64 p-3 border rounded-lg focus:ring-2 focus:ring-blue-500 resize-y font-mono text-sm"
          disabled={loading}
        />
        
        {error && (
          <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-red-600" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}
        
        <div className="mt-4 flex justify-end">
          <button
            type="submit"
            disabled={loading || !text.trim()}
            className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                Check Plagiarism
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};