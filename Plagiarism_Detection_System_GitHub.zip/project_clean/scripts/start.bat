@echo off
setlocal

echo ========================================
echo Starting Plagiarism Detection Engine
echo ========================================
echo.

set "SCRIPT_DIR=%~dp0"
set "ROOT_DIR=%SCRIPT_DIR%.."
set "BACKEND_DIR=%ROOT_DIR%\backend"
set "FRONTEND_DIR=%ROOT_DIR%\frontend"

echo [1/3] Starting Backend Server...
cd /d "%BACKEND_DIR%"
start "Plagiarism Backend" cmd /k "title Backend Server && python -m uvicorn app.main:app --reload --port 8000"

timeout /t 2 /nobreak >nul

echo [2/3] Starting Frontend Server...
cd /d "%FRONTEND_DIR%"
start "Plagiarism Frontend" cmd /k "title Frontend Server && npm run dev"

timeout /t 3 /nobreak >nul

echo [3/3] Opening browser...
start http://localhost:5173

echo.
echo ========================================
echo ? Application started!
echo Backend: http://localhost:8000
echo Frontend: http://localhost:5173
echo ========================================
pause
