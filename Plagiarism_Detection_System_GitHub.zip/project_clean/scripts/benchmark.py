# Create scripts folder
New-Item -ItemType Directory -Force -Path "scripts"

@'
"""
PHASE 7: Performance Benchmark Script
Measures speed of all components
"""

import time
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))

from core.semantic_engine import SemanticEngine
from core.lexical_engine import LexicalEngine
from core.parallel_worker_optimized import OptimizedParallelWorker


def benchmark_all():
    print("\n" + "=" * 60)
    print("📊 PHASE 7: PERFORMANCE BENCHMARK")
    print("=" * 60)
    
    results = {}
    
    # 1. Test Lexical Engine
    print("\n1️⃣ Testing Lexical Engine...")
    lexical_engine = LexicalEngine()
    text_a = "stock market trends and investments"
    text_b = "stock market trends and analysis"
    
    times = []
    for _ in range(100):
        start = time.perf_counter()
        lexical_engine.analyze_text_pair(text_a, text_b)
        times.append(time.perf_counter() - start)
    
    lexical_avg = sum(times) / len(times)
    results['lexical'] = lexical_avg
    print(f"   ✅ Average: {lexical_avg*1000:.3f}ms")
    print(f"   ⚡ Speed: {1/lexical_avg:.0f} comparisons/sec")
    
    # 2. Test Optimized Parallel Worker
    print("\n2️⃣ Testing Optimized Parallel Worker...")
    import json
    metadata_path = Path("backend/data/processed/lookup_metadata.json")
    
    if metadata_path.exists():
        with open(metadata_path, 'r') as f:
            docs = json.load(f)
        
        test_docs = docs[:50]
        worker = OptimizedParallelWorker()
        query = "stock market trends"
        
        start = time.perf_counter()
        worker.process_candidates(query, test_docs)
        parallel_time = time.perf_counter() - start
        results['parallel'] = parallel_time
        print(f"   ✅ Processed {len(test_docs)} docs in {parallel_time:.3f}s")
        print(f"   ⚡ Speed: {len(test_docs)/parallel_time:.1f} docs/sec")
    
    # 3. Test Semantic Engine
    print("\n3️⃣ Testing Semantic Engine...")
    semantic_engine = SemanticEngine()
    query = "stock market trends"
    
    times = []
    for _ in range(10):
        start = time.perf_counter()
        semantic_engine.get_top_k(query, k=5)
        times.append(time.perf_counter() - start)
    
    semantic_avg = sum(times) / len(times)
    results['semantic'] = semantic_avg
    print(f"   ✅ Average: {semantic_avg*1000:.2f}ms")
    print(f"   ⚡ Queries/sec: {1/semantic_avg:.2f}")
    
    # Summary
    print("\n" + "=" * 60)
    print("📈 BENCHMARK SUMMARY")
    print("=" * 60)
    print(f"Lexical comparison: {results['lexical']*1000:.3f}ms")
    print(f"Semantic search:    {results['semantic']*1000:.2f}ms")
    if 'parallel' in results:
        print(f"Parallel batch:     {results['parallel']:.3f}s")
    
    print("\n✅ OPTIMIZATION COMPLETE!")
    return results


if __name__ == "__main__":
    benchmark_all()
'@ | Out-File -FilePath "scripts\benchmark.py" -Encoding utf8