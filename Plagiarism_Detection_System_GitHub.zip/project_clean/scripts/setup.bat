@echo off
setlocal enabledelayedexpansion

echo ========================================
echo Setting up Plagiarism Detection Engine
echo ========================================
echo.

set "SCRIPT_DIR=%~dp0"
set "ROOT_DIR=%SCRIPT_DIR%.."
set "BACKEND_DIR=%ROOT_DIR%\backend"
set "FRONTEND_DIR=%ROOT_DIR%\frontend"

echo [1/4] Installing Python dependencies...
cd /d "%BACKEND_DIR%"
if exist requirements.txt (
    pip install -r requirements.txt
    echo ? Python dependencies installed
) else (
    echo ? requirements.txt not found
)
echo.

echo [2/4] Downloading NLTK data...
python -c "import nltk; nltk.download('stopwords'); nltk.download('punkt')"
echo.

echo [3/4] Installing Node dependencies...
cd /d "%FRONTEND_DIR%"
if exist package.json (
    call npm install
    echo ? Node dependencies installed
) else (
    echo ? package.json not found
)
echo.

echo [4/4] Setup complete!
echo.
pause
