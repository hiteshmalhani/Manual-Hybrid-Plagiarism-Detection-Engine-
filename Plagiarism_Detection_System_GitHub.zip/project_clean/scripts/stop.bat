@echo off
echo ========================================
echo Stopping Plagiarism Detection Engine
echo ========================================
echo.

echo Closing Backend Server...
taskkill /FI "WINDOWTITLE eq Backend Server" /F 2>nul
taskkill /FI "WINDOWTITLE eq Plagiarism Backend" /F 2>nul

echo Closing Frontend Server...
taskkill /FI "WINDOWTITLE eq Frontend Server" /F 2>nul
taskkill /FI "WINDOWTITLE eq Plagiarism Frontend" /F 2>nul

echo.
echo ? All servers stopped!
pause
